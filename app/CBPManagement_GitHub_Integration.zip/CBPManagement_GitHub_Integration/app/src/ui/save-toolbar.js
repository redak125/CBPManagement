/** Bouton global d'enregistrement vers Firebase ; les CRUD ne font que mettre en attente localement. */
export function installSaveToolbar({ root, manager, saveAll, canWrite = true, label = "Enregistrer" }) {
  if (!root || !manager || typeof saveAll !== "function") throw new TypeError("root, manager et saveAll sont obligatoires.");
  const wrapper = document.createElement("div");
  wrapper.className = "cbpm-save-toolbar";
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.disabled = !canWrite || !manager.isDirty();
  const count = document.createElement("span");
  count.className = "cbpm-save-count";
  count.setAttribute("aria-live", "polite");
  const status = document.createElement("span");
  status.className = "cbpm-save-status";
  status.setAttribute("role", "status");
  wrapper.append(button, count, status);
  root.append(wrapper);

  let busy = false;
  const refresh = (state = { dirty: manager.isDirty(), count: manager.pendingCount(), conflicts: manager.conflicts() }) => {
    button.disabled = !canWrite || busy || !state.dirty;
    count.textContent = state.dirty ? `${state.count} modification(s) en attente` : "Aucune modification en attente";
    if (state.conflicts?.length) status.textContent = `${state.conflicts.length} conflit(s) à résoudre.`;
  };
  const unsubscribe = manager.subscribe(refresh);
  refresh();

  button.addEventListener("click", async () => {
    if (busy || !canWrite || !manager.isDirty()) return;
    busy = true;
    button.textContent = "Enregistrement…";
    status.textContent = "Comparaison des données et enregistrement dans Firebase.";
    refresh();
    try {
      const result = await saveAll();
      const messages = [`${result.saved} enregistré(s)`, `${result.unchanged} inchangé(s)`, `${result.conflicts.length} conflit(s)`, `${result.errors.length} erreur(s)`];
      status.textContent = messages.join(" · ");
    } catch (error) {
      status.textContent = `Échec de l'enregistrement : ${error?.message ?? String(error)}. Les brouillons locaux sont conservés.`;
    } finally {
      busy = false;
      button.textContent = label;
      refresh();
    }
  });

  return {
    element: wrapper,
    dispose() { unsubscribe(); wrapper.remove(); }
  };
}
