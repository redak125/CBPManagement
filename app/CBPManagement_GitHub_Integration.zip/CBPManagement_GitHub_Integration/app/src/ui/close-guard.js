/**
 * Garde de sortie pour les brouillons locaux.
 * Les navigateurs modernes n'autorisent pas un texte personnalisé dans beforeunload.
 * Le navigateur affichera donc son avertissement natif ; les sorties internes utilisent
 * une boîte de dialogue explicite avec Enregistrer / Quitter sans enregistrer / Annuler.
 */
export function installCloseGuard({ manager, saveAll, onLeave, hasFormChanges = () => false, stageForms = async () => {} }) {
  if (!manager || typeof saveAll !== "function") throw new TypeError("manager et saveAll sont obligatoires.");
  if (typeof hasFormChanges !== "function" || typeof stageForms !== "function") throw new TypeError("hasFormChanges et stageForms doivent être des fonctions.");
  let dialog;
  let leaveRequested = false;

  function ensureDialog() {
    if (dialog?.isConnected) return dialog;
    dialog = document.createElement("dialog");
    dialog.className = "cbpm-unsaved-dialog";
    dialog.innerHTML = `
      <form method="dialog" class="cbpm-unsaved-card">
        <h2>Données non enregistrées</h2>
        <p>Des modifications sont encore présentes dans cette session.</p>
        <p>Voulez-vous les envoyer dans Firebase avant de quitter ? Le brouillon local reste conservé sur cet appareil tant qu’il n’est pas envoyé ou supprimé.</p>
        <div class="cbpm-unsaved-actions">
          <button type="button" data-action="save">Enregistrer et quitter</button>
          <button type="button" data-action="discard">Quitter sans envoyer à Firebase</button>
          <button type="button" data-action="cancel">Annuler</button>
        </div>
        <p class="cbpm-unsaved-status" aria-live="polite"></p>
      </form>`;
    document.body.append(dialog);
    return dialog;
  }

  async function requestLeave() {
    await manager.persistQueue;
    if (!manager.isDirty() && !hasFormChanges()) { await onLeave?.(); return true; }
    const dlg = ensureDialog();
    dlg.showModal();
    return await new Promise((resolve) => {
      const status = dlg.querySelector(".cbpm-unsaved-status");
      const clean = () => {
        dlg.removeEventListener("click", click);
        dlg.removeEventListener("cancel", cancel);
      };
      const finish = async (proceed) => {
        clean(); dlg.close();
        if (proceed) { leaveRequested = true; await onLeave?.(); }
        resolve(proceed);
      };
      const click = async (event) => {
        const action = event.target.closest("button")?.dataset.action;
        if (!action) return;
        if (action === "cancel") return finish(false);
        if (action === "discard") {
          // Les formulaires sont d'abord convertis en brouillons locaux ; rien n'est envoyé à Firebase.
          try {
            await stageForms();
            await manager.persist();
            return finish(true);
          } catch (error) {
            status.textContent = `Impossible de conserver le brouillon local : ${error?.message ?? String(error)}.`;
          }
        }
        if (action === "save") {
          status.textContent = "Enregistrement dans Firebase…";
          try {
            await stageForms();
            await manager.persist();
            const summary = await saveAll();
            if (summary.conflicts.length || summary.errors.length || manager.isDirty()) {
              status.textContent = `Sauvegardés : ${summary.saved}. Conflits : ${summary.conflicts.length}. Erreurs : ${summary.errors.length}. Résolvez les éléments restants avant de quitter.`;
              return;
            }
            return finish(true);
          } catch (error) {
            status.textContent = `Échec de l'enregistrement : ${error?.message ?? String(error)}. Vos brouillons restent conservés localement.`;
          }
        }
      };
      const cancel = (event) => { event.preventDefault(); void finish(false); };
      dlg.addEventListener("click", click);
      dlg.addEventListener("cancel", cancel);
    });
  }

  const beforeUnload = (event) => {
    if ((!manager.isDirty() && !hasFormChanges()) || leaveRequested) return;
    // Les modifications sont déjà enregistrées localement dans IndexedDB.
    void manager.persistQueue.catch((error) => console.error("Persistance du brouillon avant fermeture :", error));
    event.preventDefault();
    event.returnValue = ""; // message natif, le texte personnalisé n'est plus accepté par les navigateurs
  };
  window.addEventListener("beforeunload", beforeUnload);

  return {
    requestLeave,
    dispose() { window.removeEventListener("beforeunload", beforeUnload); dialog?.remove(); }
  };
}
