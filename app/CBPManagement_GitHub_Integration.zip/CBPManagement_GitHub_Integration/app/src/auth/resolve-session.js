import { doc, getDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";

/**
 * Reprend les documents utilisés par le Web fourni : utilisateurs/{uid} et entreprises/{entrepriseId}.
 * Cette fonction ne crée, ne renomme et ne supprime aucun compte.
 */
export async function resolveExistingWebSession(db, firebaseUser) {
  if (!firebaseUser?.uid) throw new Error("Session Firebase absente.");
  const userSnapshot = await getDoc(doc(db, "utilisateurs", firebaseUser.uid));
  if (!userSnapshot.exists()) throw new Error("Ce compte n’est rattaché à aucune entreprise.");
  const profile = userSnapshot.data();
  if (!profile.entrepriseId) throw new Error("Le compte ne contient pas d’identifiant d’entreprise.");

  const companySnapshot = await getDoc(doc(db, "entreprises", profile.entrepriseId));
  if (!companySnapshot.exists()) throw new Error("Entreprise introuvable.");
  const company = { id: companySnapshot.id, ...companySnapshot.data() };
  if (company.etat === "suspendue") throw new Error("Cette entreprise est suspendue. Contactez le fournisseur de l’application.");

  return {
    user: firebaseUser,
    profile,
    company,
    role: profile.role,
    canWrite: profile.role === "admin" // même règle que le Web actuel
  };
}
