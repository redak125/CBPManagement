const norm = (value) => String(value ?? "").trim().normalize("NFKC").toLocaleLowerCase("fr");
const SEP = "\u001f";

const simple = (table, field = "nom", optional = false) => ({
  table,
  key: (record) => norm(record[field]),
  valueKey: (value) => norm(value),
  optional
});

/** Relations Java exprimées par des libellés, alors que le Web cible utilise des IDs Firestore. */
export const LEGACY_REFERENCE_RULES = {
  appro: {
    fournisseur: simple("fournisseur"),
    produit: {
      table: "prod_appro",
      key: (record) => `${norm(record.nature)}${SEP}${norm(record.nom)}`,
      valueKey: (value, sourceRow) => `${norm(sourceRow.nature)}${SEP}${norm(value)}`
    },
    silo: simple("silo", "nom", true)
  },
  prod: {
    client: simple("client"),
    produit: {
      table: "prod_fini",
      key: (record) => `${norm(record.nature)}${SEP}${norm(record.nom)}`,
      valueKey: (value, sourceRow) => `${norm(sourceRow.nature === "Production" ? "Produit" : "Service")}${SEP}${norm(value)}`
    },
    silo: simple("silo", "nom", true),
    camion: simple("materiel", "immat", true),
    chauffeur: {
      table: "personnel",
      key: (record) => norm(`${record.nom ?? ""} ${record.prenom ?? ""}`),
      valueKey: (value) => norm(value),
      optional: true
    }
  },
  recette: { debiteur: simple("client") },
  facture: { client: simple("client") },
  depense: {
    aff: simple("affect"),
    sousaff: {
      table: "sousaff",
      key: (record) => `${norm(record.aff)}${SEP}${norm(record.nom)}`,
      valueKey: (value, sourceRow) => `${norm(sourceRow.aff)}${SEP}${norm(value)}`,
      optional: true
    },
    benef: {
      table: "personnel",
      key: (record) => norm(`${record.nom ?? ""} ${record.prenom ?? ""}`),
      valueKey: (value) => norm(value),
      onlyWhen: (sourceRow) => sourceRow.aff === "Charges du personnel",
      optional: true
    }
  }
};

function rulesForTargetTable(table) {
  const matches = Object.values(LEGACY_REFERENCE_RULES).flatMap((rules) => Object.values(rules))
    .filter((rule) => rule.table === table);
  return matches.length ? matches : [];
}

function makeIndex(table, existingByTable, sourceItems) {
  const byKey = new Map();
  const rules = rulesForTargetTable(table);
  const add = (id, row) => {
    if (!id) return;
    let indexedRow = row;
    if (table === "sousaff") {
      const sourceAff = row.aff;
      const remoteAff = existingByTable.get("affect")?.get(sourceAff)?.nom;
      const plannedAff = sourceItems.find((item) => item.table === "affect" && item.id === sourceAff)?.source?.nom;
      const affName = remoteAff ?? plannedAff;
      if (affName) indexedRow = { ...row, aff: affName };
    }
    for (const rule of rules) {
      const key = rule.key(indexedRow);
      if (!key || key === SEP) continue;
      const list = byKey.get(key) ?? [];
      if (!list.some((item) => item.id === id)) list.push({ id, row });
      byKey.set(key, list);
    }
  };
  for (const [id, row] of existingByTable.get(table)?.entries() ?? []) add(id, row);
  for (const item of sourceItems.filter((x) => x.table === table && x.id && x.source)) add(item.id, item.source);
  // Un doublon identifié dans le fichier source rend lui aussi la référence ambiguë.
  for (const item of sourceItems.filter((x) => x.table === table && x.action === "duplicate-in-source" && x.source)) {
    const rule = rules[0];
    if (!rule) continue;
    const key = rule.key(item.source);
    const list = byKey.get(key) ?? [];
    list.push({ id: `source-duplicate-${item.sourceIndex}`, row: item.source });
    byKey.set(key, list);
  }
  return byKey;
}

/** Crée les index à partir des données déjà présentes et de toutes les lignes du plan. */
export function buildLegacyReferenceIndexes(_parsed, existingByTable = new Map(), planItems = []) {
  const names = new Set(Object.values(LEGACY_REFERENCE_RULES).flatMap((rules) => Object.values(rules).map((rule) => rule.table)));
  return new Map([...names].map((table) => [table, makeIndex(table, existingByTable, planItems)]));
}

/**
 * Convertit les références exactes. Toute absence ou ambiguïté est renvoyée pour revue.
 * Les noms ne sont jamais rapprochés par simple ressemblance ni par ordre de liste.
 */
export function mapLegacyReferences(table, row, indexes) {
  const out = { ...row };
  const originalRow = { ...row };
  const review = [];
  const rules = LEGACY_REFERENCE_RULES[table] ?? {};
  for (const [field, declaredRule] of Object.entries(rules)) {
    let rule = declaredRule;
    if (table === "depense" && field === "sousaff") {
      if (originalRow.aff === "Fournisseur") rule = simple("fournisseur");
      else if (originalRow.aff === "Remboursement client") rule = simple("client");
    }
    if (rule.onlyWhen && !rule.onlyWhen(originalRow)) continue;
    const label = out[field];
    if (label === null || label === undefined || String(label).trim() === "") continue;
    const key = rule.valueKey(label, originalRow);
    const candidates = indexes.get(rule.table)?.get(key) ?? [];
    if (candidates.length === 1) out[field] = candidates[0].id;
    else {
      review.push({ table, field, value: label, targetTable: rule.table,
        status: candidates.length ? "ambiguous" : rule.optional ? "optional-unmatched" : "unmatched",
        candidateIds: candidates.map((x) => x.id) });
    }
  }
  return { row: out, review };
}
