const LIMITS = { bytes: 256 * 1024 * 1024, expandedBytes: 512 * 1024 * 1024, tables: 10000, records: 10000000, fields: 10000, stringBytes: 200 * 1024 * 1024 };

function decodeEscaped(value) {
  return value.replace(/\\(t|n|r|\\)/g, (_, code) => ({ t: "\t", n: "\n", r: "\r", "\\": "\\" })[code]);
}

function parseLegacyText(text) {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/);
  if (!lines[0]?.startsWith("#CBPM")) throw new Error("En-tête .cbpm texte non reconnu.");
  const tables = {};
  for (const line of lines.slice(1)) {
    if (!line) continue;
    const parts = line.split("\t");
    const table = parts.shift();
    if (!table) continue;
    const row = {};
    for (const part of parts) {
      const i = part.indexOf("=");
      if (i > 0) row[part.slice(0, i)] = decodeEscaped(part.slice(i + 1));
    }
    (tables[table] ??= []).push(row);
  }
  return { format: "CBPM-text", version: 1, tables };
}

async function gunzip(buffer) {
  if (typeof DecompressionStream !== "function") throw new Error("Ce navigateur ne prend pas en charge la décompression gzip requise pour les fichiers .cbpm.");
  const stream = new Blob([buffer]).stream().pipeThrough(new DecompressionStream("gzip"));
  const reader = stream.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > LIMITS.expandedBytes) {
        await reader.cancel();
        throw new Error("Le fichier .cbpm décompressé dépasse la limite de sécurité.");
      }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const output = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { output.set(chunk, offset); offset += chunk.byteLength; }
  return output.buffer;
}

function parseBinary(buffer) {
  const view = new DataView(buffer);
  let offset = 0;
  const need = (count) => {
    if (!Number.isSafeInteger(count) || count < 0 || offset + count > view.byteLength) throw new Error("Fichier .cbpm tronqué ou corrompu.");
  };
  const readInt = () => { need(4); const value = view.getInt32(offset, false); offset += 4; return value; };
  const readString = () => {
    const length = readInt();
    if (length < 0 || length > LIMITS.stringBytes) throw new Error(`Longueur de chaîne invalide : ${length}.`);
    need(length);
    const bytes = new Uint8Array(buffer, offset, length);
    offset += length;
    return new TextDecoder("utf-8", { fatal: false }).decode(bytes);
  };

  need(5);
  const magic = String.fromCharCode(view.getUint8(0), view.getUint8(1), view.getUint8(2), view.getUint8(3));
  offset = 4;
  if (magic !== "CBPM") throw new Error("Signature binaire CBPM invalide.");
  const version = view.getUint8(offset++);
  if (version !== 2) throw new Error(`Version .cbpm non prise en charge : ${version}. La version attendue est 2.`);
  const tableCount = readInt();
  if (tableCount < 0 || tableCount > LIMITS.tables) throw new Error("Nombre de tables invalide.");

  const tables = {};
  for (let t = 0; t < tableCount; t++) {
    const name = readString();
    if (!name || Object.prototype.hasOwnProperty.call(tables, name)) throw new Error("Nom de table vide ou dupliqué dans le fichier .cbpm.");
    const recordCount = readInt();
    if (recordCount < 0 || recordCount > LIMITS.records) throw new Error(`Nombre d'enregistrements invalide dans ${name}.`);
    const rows = [];
    for (let r = 0; r < recordCount; r++) {
      const fieldCount = readInt();
      if (fieldCount < 0 || fieldCount > LIMITS.fields) throw new Error(`Nombre de champs invalide dans ${name}.`);
      const row = {};
      for (let f = 0; f < fieldCount; f++) {
        const key = readString();
        if (!key || new TextEncoder().encode(key).byteLength > 4096 || Object.prototype.hasOwnProperty.call(row, key)) {
          throw new Error(`Clé de champ vide, trop longue ou dupliquée dans ${name}.`);
        }
        row[key] = readString();
      }
      rows.push(row);
    }
    tables[name] = rows;
  }
  if (offset !== view.byteLength) throw new Error("Le fichier contient des données supplémentaires non reconnues.");
  return { format: "CBPM-binary", version, tables };
}

export async function readLegacyCbpm(file) {
  if (!(file instanceof Blob)) throw new TypeError("Un fichier .cbpm est attendu.");
  if (file.size <= 0 || file.size > LIMITS.bytes) throw new Error("Taille du fichier .cbpm invalide ou supérieure à la limite d'importation.");
  const raw = await file.arrayBuffer();
  const bytes = new Uint8Array(raw, 0, Math.min(4, raw.byteLength));
  if (bytes[0] === 0x1f && bytes[1] === 0x8b) {
    const expanded = await gunzip(raw);
    return parseBinary(expanded);
  }
  return parseLegacyText(new TextDecoder("utf-8").decode(raw));
}
