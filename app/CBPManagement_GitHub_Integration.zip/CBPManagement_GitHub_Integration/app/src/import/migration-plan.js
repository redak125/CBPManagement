import { cleanFirestoreDocument, isDeepEqual } from "../data/three-way-merge.js";
import { buildLegacyReferenceIndexes, mapLegacyReferences } from "./reference-mapper.js";

const COLLECTIONS = new Set([
  "client", "fournisseur", "appro", "prod", "recette", "depense", "transfert", "personnel", "materiel",
  "prod_appro", "silo", "prod_fini", "affect", "sousaff", "facture", "regstock", "journal", "app_meta", "param"
]);
const NUMBER_FIELDS = new Set(["qte", "pu", "taux", "ht", "tvam", "ttc", "dosage", "montant", "remise", "net", "marge", "theorique", "reel", "ecart"]);
const BOOLEAN_FIELDS = new Set(["tva", "active", "actif", "deleted"]);
const UNIQUE_FIELDS = {
  client: ["nom"], fournisseur: ["nom"], silo: ["nom"], affect: ["nom"],
  materiel: ["immat"], personnel: ["nom", "prenom"], prod_appro: ["nature", "nom"], prod_fini: ["nature", "nom"]
};

const normalizeText = (v) => String(v ?? "").trim().normalize("NFKC").toLocaleLowerCase("fr");
function normalizeValue(key, value) {
  if (NUMBER_FIELDS.has(key) && value !== "") {
    const n = Number(String(value).replace(/\s/g, "").replace(",", "."));
    return Number.isFinite(n) ? n : value;
  }
  if (BOOLEAN_FIELDS.has(key)) {
    if (value === true || value === 1 || value === "1" || value === "true") return true;
    if (value === false || value === 0 || value === "0" || value === "false") return false;
    return value; // ne pas convertir arbitrairement « Oui », « Non », etc.
  }
  return value;
}
function normalizeRow(row) {
  const out = {};
  for (const [key, value] of Object.entries(row ?? {})) out[key] = normalizeValue(key, value);
  return out;
}
function uniqueKey(table, row) {
  const fields = UNIQUE_FIELDS[table];
  if (!fields || fields.some((f) => !String(row[f] ?? "").trim())) return null;
  return fields.map((f) => normalizeText(row[f])).join("\u001f");
}
async function sha256(text) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((x) => x.toString(16).padStart(2, "0")).join("");
}

/**
 * Produit un plan de migration en lecture seule. Aucune écriture Firestore n'est faite ici.
 * existingByTable = Map(collection -> Map(docId -> Firestore data)).
 */
export async function buildLegacyMigrationPlan(parsed, existingByTable = new Map()) {
  const sourceHash = await sha256(JSON.stringify(parsed.tables));
  const sourceTables = Object.keys(parsed.tables ?? {});
  const warnings = [];
  const items = [];

  for (const table of sourceTables) {
    if (!COLLECTIONS.has(table)) {
      warnings.push(`Table ignorée car non reconnue par le schéma métier : ${table}`);
      continue;
    }
    if (table === "param") {
      warnings.push("Les paramètres Java sont exclus du .cbpm récent et stockés dans les préférences locales. Une fiche paramétrage devra être vérifiée séparément.");
      continue;
    }
    const seenSourceKeys = new Map();
    for (let index = 0; index < parsed.tables[table].length; index++) {
      const row = normalizeRow(parsed.tables[table][index]);
      const unique = uniqueKey(table, row);
      if (unique && seenSourceKeys.has(unique)) {
        items.push({ table, sourceIndex: index, id: null, action: "duplicate-in-source", source: row, duplicateOf: seenSourceKeys.get(unique) });
        continue;
      }
      if (unique) seenSourceKeys.set(unique, index);
      const docs = [...(existingByTable.get(table)?.entries() ?? [])];
      const matches = unique ? docs.filter(([, data]) => uniqueKey(table, cleanFirestoreDocument(data)) === unique) : [];
      const identity = `${table}\n${JSON.stringify(row, Object.keys(row).sort())}\n${index}`;
      const generatedId = `legacy_${(await sha256(identity)).slice(0, 24)}`;

      if (matches.length === 0 && existingByTable.get(table)?.has(generatedId)) {
        const existingData = existingByTable.get(table).get(generatedId);
        const remote = cleanFirestoreDocument(existingData);
        const same = isDeepEqual(row, remote);
        items.push({ table, sourceIndex: index, id: generatedId, action: same ? "already-present" : "review-existing",
          source: row, remote, differences: Object.keys({ ...row, ...remote }).filter((k) => !isDeepEqual(row[k], remote[k])) });
      } else if (matches.length === 1) {
        const [existingId, existingData] = matches[0];
        const remote = cleanFirestoreDocument(existingData);
        const same = isDeepEqual(row, remote);
        items.push({ table, sourceIndex: index, id: existingId, action: same ? "already-present" : "review-existing",
          source: row, remote, differences: Object.keys({ ...row, ...remote }).filter((k) => !isDeepEqual(row[k], remote[k])) });
      } else if (matches.length > 1) {
        items.push({ table, sourceIndex: index, id: null, action: "ambiguous-match", source: row,
          candidates: matches.map(([id]) => id) });
      } else {
        items.push({ table, sourceIndex: index, id: generatedId, action: "create", source: row });
      }
    }
  }

  const summary = items.reduce((acc, item) => { acc[item.action] = (acc[item.action] ?? 0) + 1; return acc; }, {});
  return { sourceHash, markerId: `legacy_${sourceHash.slice(0, 24)}`, format: parsed.format, version: parsed.version, summary, warnings, items };
}

/** Ajoute au plan la conversion des relations texte Java vers les IDs Web. */
export function mapMigrationPlanReferences(plan, parsed, existingByTable = new Map()) {
  const indexes = buildLegacyReferenceIndexes(parsed, existingByTable, plan.items);
  const items = plan.items.map((item) => {
    if (!item.source || !item.id || !["create", "review-existing", "already-present"].includes(item.action)) return item;
    const mapped = mapLegacyReferences(item.table, item.source, indexes);
    const next = { ...item, sourceMapped: mapped.row, referenceReview: mapped.review };
    if (mapped.review.length && item.action === "create") next.action = "review-references";
    if (item.remote) {
      const same = isDeepEqual(mapped.row, item.remote);
      next.action = same ? "already-present" : "review-existing";
      next.differences = Object.keys({ ...mapped.row, ...item.remote }).filter((key) => !isDeepEqual(mapped.row[key], item.remote[key]));
    }
    return next;
  });
  const summary = items.reduce((acc, item) => { acc[item.action] = (acc[item.action] ?? 0) + 1; return acc; }, {});
  return { ...plan, items, summary };
}

export function toFirestoreMigrationDocument(item) {
  if (item.action !== "create" || !item.id) throw new Error("Seules les nouvelles lignes confirmées peuvent être converties en documents.");
  if (item.referenceReview?.length) throw new Error("Des références liées doivent être résolues manuellement avant l'importation.");
  return { ...(item.sourceMapped ?? item.source), origineMigration: "CBPM-Java", migrationId: item.id };
}
