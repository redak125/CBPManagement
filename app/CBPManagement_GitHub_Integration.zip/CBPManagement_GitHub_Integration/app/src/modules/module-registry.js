/**
 * Inventaire cible des écrans CBPManagement, à porter depuis le code Swing.
 * Les noms de collections reprennent les tables constatées dans la source Java.
 */
export const MODULES = [
  { id: "dashboard", title: "Tableau de bord", group: "gestion", tables: ["prod", "appro", "recette", "depense", "transfert", "regstock"] },
  { id: "clients", title: "Clients", group: "gestion", tables: ["client", "facture", "prod", "recette", "depense"] },
  { id: "fournisseurs", title: "Fournisseurs", group: "gestion", tables: ["fournisseur", "appro", "depense"] },
  { id: "appro", title: "Approvisionnements et services", group: "gestion", tables: ["appro", "fournisseur", "prod_appro", "silo"] },
  { id: "production", title: "Production et services", group: "gestion", tables: ["prod", "client", "prod_fini", "silo", "materiel", "personnel", "facture"] },
  { id: "regstock", title: "Régularisation du stock", group: "gestion", tables: ["regstock", "appro", "prod", "prod_appro", "silo"] },
  { id: "factures", title: "Facturation", group: "finances", tables: ["facture", "prod", "client"] },
  { id: "recettes", title: "Recettes", group: "finances", tables: ["recette", "client"] },
  { id: "depenses", title: "Dépenses", group: "finances", tables: ["depense", "affect", "sousaff", "fournisseur", "client", "personnel"] },
  { id: "transferts", title: "Transferts de trésorerie", group: "finances", tables: ["transfert"] },
  { id: "dettes_clients", title: "Dettes clients", group: "finances", tables: ["prod", "recette", "depense", "client"] },
  { id: "dettes_fournisseurs", title: "Dettes fournisseurs", group: "finances", tables: ["appro", "depense", "fournisseur"] },
  { id: "controle_gestion", title: "Contrôle de gestion", group: "finances", tables: ["prod", "appro", "recette", "depense", "transfert", "regstock"] },
  { id: "personnel", title: "Personnel", group: "ressources", tables: ["personnel"] },
  { id: "materiels", title: "Matériels", group: "ressources", tables: ["materiel", "prod"] },
  { id: "mail", title: "Messagerie", group: "ressources", tables: [], storage: "service sécurisé à définir" },
  { id: "parametres", title: "Paramètres", group: "systeme", tables: ["parametres"] },
  { id: "rapports", title: "Rapports", group: "systeme", tables: ["app_meta", "client", "fournisseur", "appro", "prod", "recette", "depense", "transfert", "personnel", "materiel", "prod_appro", "silo", "prod_fini", "facture", "regstock", "journal"] },
  { id: "journal", title: "Journal des opérations", group: "systeme", tables: ["journal"] },
  { id: "users", title: "Gestion des utilisateurs", group: "systeme", tables: [], collection: "utilisateurs/{uid}", access: "administrateur uniquement" }
];

export const FIRESTORE_COMPANY_COLLECTIONS = [
  "app_meta", "affect", "sousaff", "client", "fournisseur", "appro", "prod", "recette", "depense",
  "transfert", "personnel", "materiel", "prod_appro", "silo", "prod_fini", "facture", "regstock", "journal",
  "parametres"
];

export const CROSS_CUTTING_FEATURES = [
  "recherche et filtres", "tri et totaux", "impression et aperçus", "factures et bons PDF",
  "import/export Excel", "import .cbpm", "sauvegarde et restauration", "annuler/rétablir",
  "journalisation", "gestion des utilisateurs", "FR/EN/AR et prise en charge RTL", "thèmes clair/sombre"
];
