import { cleanFirestoreDocument, isDeepEqual, mergeThreeWay } from "./three-way-merge.js";

const keyOf = (table, id) => `${table}\u0000${id}`;
const clone = (value) => value == null ? value : JSON.parse(JSON.stringify(value));

export class ChangeManager {
  constructor({ store, scopeKey }) {
    if (!store || !scopeKey) throw new TypeError("store et scopeKey sont obligatoires.");
    this.store = store;
    this.scopeKey = scopeKey;
    this.remote = new Map();
    this.changes = new Map();
    this.listeners = new Set();
    this.persistQueue = Promise.resolve();
    this.saving = false;
    this.lastSave = null;
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify() {
    const state = { dirty: this.isDirty(), count: this.pendingCount(), conflicts: this.conflicts() };
    for (const listener of this.listeners) listener(state);
  }

  isDirty() { return this.changes.size > 0; }
  pendingCount() { return this.changes.size; }
  conflicts() { return [...this.changes.values()].filter((x) => x.conflicts?.length || x.conflictReason); }

  persist() {
    const snapshot = [...this.changes.values()].map((x) => clone(x));
    this.persistQueue = this.persistQueue.then(() => this.store.write(this.scopeKey, snapshot));
    return this.persistQueue;
  }

  async restoreDraft() {
    const rows = await this.store.read(this.scopeKey);
    this.changes.clear();
    for (const row of rows) this.changes.set(keyOf(row.table, row.id), row);
    this.notify();
    return rows.length;
  }

  setRemoteTable(table, docs) {
    const tableMap = new Map();
    for (const [id, data] of docs) tableMap.set(id, { id, ...data });
    this.remote.set(table, tableMap);

    for (const op of this.changes.values()) {
      if (op.table !== table) continue;
      const remoteDoc = tableMap.get(op.id);
      if (op.base === null) {
        if (remoteDoc) {
          op.conflictReason = "Un document distant possède déjà cet identifiant.";
          op.conflictRemote = cleanFirestoreDocument(remoteDoc);
        } else {
          op.conflictReason = null;
          op.conflictRemote = null;
        }
        continue;
      }
      if (!remoteDoc) {
        op.conflictReason = "Cet enregistrement a été supprimé à distance.";
        op.conflictRemote = null;
        continue;
      }
      const remote = cleanFirestoreDocument(remoteDoc);
      if (remote.deleted === true && op.local?.deleted !== true) {
        op.conflictReason = "Cet enregistrement a été supprimé à distance.";
        op.conflictRemote = remote;
        continue;
      }
      const result = mergeThreeWay(op.base, op.local, remote);
      if (result.conflicts.length) {
        op.conflicts = result.conflicts;
        op.conflictRemote = remote;
      } else {
        op.base = remote;
        op.baseVersion = Number(remoteDoc.version) || 0;
        op.local = result.merged;
        op.conflicts = [];
        op.conflictReason = null;
        op.conflictRemote = null;
      }
    }
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  rows(table, { includeDeleted = false } = {}) {
    const rows = new Map(this.remote.get(table) ?? []);
    for (const op of this.changes.values()) {
      if (op.table !== table) continue;
      if (op.local === null) rows.delete(op.id);
      else rows.set(op.id, { id: op.id, ...op.local, version: op.baseVersion ?? 0, _pending: true,
        _conflict: Boolean(op.conflicts?.length || op.conflictReason) });
    }
    const out = [...rows.values()];
    return includeDeleted ? out : out.filter((r) => !r.deleted);
  }

  create(table, id, data) {
    const key = keyOf(table, id);
    if (this.remote.get(table)?.has(id) || this.changes.has(key)) throw new Error("Identifiant déjà utilisé.");
    this.changes.set(key, { table, id, base: null, baseVersion: null, local: cleanFirestoreDocument(data), conflicts: [], conflictReason: null });
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  update(table, id, patch) {
    const key = keyOf(table, id);
    const existing = this.changes.get(key);
    const remoteDoc = this.remote.get(table)?.get(id);
    if (!existing && !remoteDoc) throw new Error("Enregistrement introuvable dans la copie de travail.");
    const base = existing ? existing.base : cleanFirestoreDocument(remoteDoc);
    if (base === null) {
      const local = { ...existing.local, ...cleanFirestoreDocument(patch) };
      this.changes.set(key, { ...existing, local });
    } else {
      const local = { ...(existing?.local ?? base), ...cleanFirestoreDocument(patch) };
      this.changes.set(key, {
        table, id, base, baseVersion: existing?.baseVersion ?? (Number(remoteDoc?.version) || 0),
        local, conflicts: existing?.conflicts ?? [], conflictReason: existing?.conflictReason ?? null,
        conflictRemote: existing?.conflictRemote ?? null
      });
    }
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  softDelete(table, id) {
    const key = keyOf(table, id);
    const existing = this.changes.get(key);
    if (existing?.base === null) {
      this.changes.delete(key); // création locale annulée avant sauvegarde
    } else {
      const remoteDoc = this.remote.get(table)?.get(id);
      if (!existing && !remoteDoc) throw new Error("Enregistrement introuvable.");
      const base = existing?.base ?? cleanFirestoreDocument(remoteDoc);
      const local = { ...(existing?.local ?? base), deleted: true };
      this.changes.set(key, { table, id, base, baseVersion: existing?.baseVersion ?? (Number(remoteDoc?.version) || 0),
        local, conflicts: existing?.conflicts ?? [], conflictReason: existing?.conflictReason ?? null,
        conflictRemote: existing?.conflictRemote ?? null });
    }
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  resolveStructuralConflict(table, id, choice, newId = null) {
    const key = keyOf(table, id), op = this.changes.get(key);
    if (!op?.conflictReason) throw new Error("Aucun conflit structurel à résoudre.");

    if (choice === "discard-local" || choice === "use-remote") {
      this.changes.delete(key);
    } else if (choice === "restore-local" && op.conflictReason.includes("supprimé à distance")) {
      if (op.conflictRemote?.deleted === true) {
        op.base = op.conflictRemote;
        op.baseVersion = Number(this.remote.get(table)?.get(id)?.version) || 0;
        op.local = { ...op.local, deleted: false };
      } else {
        op.base = null; // la ligne a été physiquement supprimée : restauration par recréation
        op.baseVersion = null;
      }
      op.conflicts = [];
      op.conflictReason = null;
      op.conflictRemote = null;
      this.changes.set(key, op);
    } else if (choice === "duplicate-local" && op.conflictReason.includes("identifiant") && newId && newId !== id) {
      const newKey = keyOf(table, newId);
      if (this.changes.has(newKey) || this.remote.get(table)?.has(newId)) throw new Error("Le nouvel identifiant est déjà utilisé.");
      this.changes.delete(key);
      this.changes.set(newKey, { ...op, id: newId, base: null, baseVersion: null,
        conflicts: [], conflictReason: null, conflictRemote: null, local: clone(op.local) });
    } else {
      throw new Error("Choix non compatible avec ce conflit. Relisez les données avant de continuer.");
    }
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  resolveConflict(table, id, fieldChoices = {}) {
    const key = keyOf(table, id), op = this.changes.get(key);
    if (!op || !op.conflictRemote) throw new Error("Aucun conflit avec une version distante disponible.");
    const remote = op.conflictRemote;
    const merge = mergeThreeWay(op.base ?? {}, op.local ?? {}, remote);
    const local = { ...merge.merged };
    for (const conflict of op.conflicts ?? []) {
      const choice = fieldChoices[conflict.field];
      if (choice === "remote") {
        if (Object.prototype.hasOwnProperty.call(remote, conflict.field)) local[conflict.field] = remote[conflict.field];
        else delete local[conflict.field];
      } else if (choice === "local") {
        if (conflict.local === undefined) delete local[conflict.field];
        else local[conflict.field] = conflict.local;
      } else if (choice && typeof choice === "object" && Object.prototype.hasOwnProperty.call(choice, "value")) {
        local[conflict.field] = choice.value;
      } else {
        throw new Error(`Choisissez une valeur pour le champ « ${conflict.field} ».`);
      }
    }
    op.base = remote;
    op.baseVersion = Number(this.remote.get(table)?.get(id)?.version) || 0;
    op.local = local;
    op.conflicts = [];
    op.conflictReason = null;
    op.conflictRemote = null;
    this.changes.set(key, op);
    void this.persist().catch((e) => console.error("Brouillon CBPManagement :", e));
    this.notify();
  }

  async saveAll({ db, companyId, userEmail, firestore }) {
    if (this.saving) throw new Error("Une sauvegarde est déjà en cours.");
    if (!db || !companyId || !firestore) throw new TypeError("Configuration Firestore incomplète.");
    this.saving = true;
    const summary = { saved: 0, unchanged: 0, conflicts: [], errors: [] };
    try {
      for (const [key, currentOp] of [...this.changes.entries()]) {
        if (currentOp.conflicts?.length || currentOp.conflictReason) {
          summary.conflicts.push({ table: currentOp.table, id: currentOp.id,
            fields: (currentOp.conflicts ?? []).map((x) => x.field), reason: currentOp.conflictReason ?? "Conflit de champs." });
          continue;
        }
        const op = clone(currentOp);
        try {
          const ref = firestore.doc(db, "entreprises", companyId, op.table, op.id);
          const result = await firestore.runTransaction(db, async (tx) => {
            const snap = await tx.get(ref);
            const remoteRaw = snap.exists() ? snap.data() : null;
            if (op.base === null) {
              if (remoteRaw) return { status: "conflict", reason: "L'identifiant existe déjà dans Firebase." };
              const data = { ...op.local, version: 1, majPar: userEmail ?? "", majLe: firestore.serverTimestamp() };
              tx.set(ref, data);
              return { status: "saved", data: { ...op.local, version: 1, majPar: userEmail ?? "" } };
            }
            if (!remoteRaw) return { status: "conflict", reason: "L'enregistrement a été supprimé à distance." };
            const remote = cleanFirestoreDocument(remoteRaw);
            if (remote.deleted === true && op.local?.deleted !== true) {
              return { status: "conflict", reason: "Cet enregistrement a été supprimé à distance." };
            }
            const merged = mergeThreeWay(op.base, op.local, remote);
            if (merged.conflicts.length) return { status: "conflict", conflicts: merged.conflicts };
            if (isDeepEqual(merged.merged, remote)) return { status: "unchanged", data: { ...remote, version: Number(remoteRaw.version) || 0 } };
            const nextVersion = (Number(remoteRaw.version) || 0) + 1;
            const data = { ...merged.merged, version: nextVersion, majPar: userEmail ?? "", majLe: firestore.serverTimestamp() };
            tx.set(ref, data);
            return { status: "saved", data: { ...merged.merged, version: nextVersion, majPar: userEmail ?? "" } };
          });

          if (result.status === "conflict") {
            const live = this.changes.get(key);
            if (live) {
              try {
                const snap = await firestore.getDoc(ref);
                const remoteRaw = snap.exists() ? snap.data() : null;
                const remote = remoteRaw ? cleanFirestoreDocument(remoteRaw) : null;
                live.conflictRemote = remote;
                if (remoteRaw) {
                  this.remote.set(op.table, this.remote.get(op.table) ?? new Map());
                  this.remote.get(op.table).set(op.id, { id: op.id, ...remoteRaw });
                }
                if (result.reason) {
                  live.conflicts = [];
                  live.conflictReason = result.reason;
                } else if (!remote) {
                  live.conflicts = [];
                  live.conflictReason = "Cet enregistrement a été supprimé à distance.";
                } else {
                  const latest = mergeThreeWay(live.base ?? {}, live.local ?? {}, remote);
                  live.conflicts = latest.conflicts;
                  live.conflictReason = null;
                  if (!latest.conflicts.length) {
                    live.base = remote;
                    live.baseVersion = Number(remoteRaw.version) || 0;
                    live.local = latest.merged;
                    live.conflictRemote = null;
                  }
                }
              } catch { /* le conflit reste visible même si la relecture échoue */
                live.conflicts = result.conflicts ?? [];
                live.conflictReason = result.reason ?? "Conflit distant à vérifier.";
              }
            }
            summary.conflicts.push({ table: op.table, id: op.id,
              fields: (result.conflicts ?? []).map((x) => x.field), reason: result.reason ?? "Conflit de champs." });
            continue;
          }

          this.remote.set(op.table, this.remote.get(op.table) ?? new Map());
          this.remote.get(op.table).set(op.id, { id: op.id, ...result.data });
          const live = this.changes.get(key);
          if (live === currentOp) {
            this.changes.delete(key);
          } else if (live) {
            // Des saisies ont pu arriver pendant la transaction. La version
            // validée (op.local) devient alors la nouvelle base des saisies récentes.
            const committed = cleanFirestoreDocument(result.data);
            const rebased = mergeThreeWay(op.local ?? {}, live.local ?? {}, committed);
            live.base = committed;
            live.baseVersion = Number(result.data.version) || 0;
            live.local = rebased.merged;
            live.conflicts = rebased.conflicts;
            live.conflictReason = null;
            live.conflictRemote = rebased.conflicts.length ? committed : null;
          }
          if (result.status === "saved") summary.saved++;
          else summary.unchanged++;
        } catch (error) {
          summary.errors.push({ table: op.table, id: op.id, message: error?.message ?? String(error) });
        }
      }
      this.lastSave = new Date().toISOString();
      await this.persistQueue;
      if (!this.changes.size) await this.store.remove(this.scopeKey);
      else await this.persist();
      this.notify();
      return summary;
    } finally {
      this.saving = false;
      this.notify();
    }
  }
}

export { keyOf as changeKey };
