const DB_NAME = "cbpmanagement-local-drafts";
const DB_VERSION = 1;
const STORE_NAME = "drafts";

function openDatabase() {
  return new Promise((resolve, reject) => {
    if (!globalThis.indexedDB) {
      reject(new Error("IndexedDB n'est pas disponible dans ce navigateur."));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Ouverture du stockage local impossible."));
  });
}

export class DraftStore {
  async read(key) {
    const db = await openDatabase();
    try {
      return await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readonly");
        const req = tx.objectStore(STORE_NAME).get(key);
        req.onsuccess = () => resolve(req.result?.changes ?? []);
        req.onerror = () => reject(req.error);
      });
    } finally { db.close(); }
  }

  async write(key, changes) {
    const db = await openDatabase();
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).put({ key, savedAt: new Date().toISOString(), changes });
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error ?? new Error("Écriture du brouillon local impossible."));
        tx.onabort = () => reject(tx.error ?? new Error("Écriture locale annulée."));
      });
    } finally { db.close(); }
  }

  async remove(key) {
    const db = await openDatabase();
    try {
      await new Promise((resolve, reject) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).delete(key);
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
      });
    } finally { db.close(); }
  }
}
