const META_FIELDS = new Set(["id", "version", "majPar", "majLe"]);

function canonical(value) {
  if (value === undefined) return { __undefined: true };
  if (value === null || typeof value !== "object") return value;
  if (value instanceof Date) return { __date: value.toISOString() };
  if (Array.isArray(value)) return value.map(canonical);
  if (typeof value.toMillis === "function") return { __timestamp: value.toMillis() };
  const out = {};
  for (const key of Object.keys(value).sort()) out[key] = canonical(value[key]);
  return out;
}

export function isDeepEqual(a, b) {
  return JSON.stringify(canonical(a)) === JSON.stringify(canonical(b));
}

export function cleanFirestoreDocument(data = {}) {
  const out = {};
  for (const [key, value] of Object.entries(data ?? {})) {
    if (META_FIELDS.has(key) || value === undefined) continue;
    out[key] = value;
  }
  return out;
}

/**
 * Three-way merge: base = last common version, local = staged changes,
 * remote = latest Firestore version. Only same-field divergent edits conflict.
 */
export function mergeThreeWay(base = {}, local = {}, remote = {}) {
  const merged = { ...remote };
  const conflicts = [];
  const keys = new Set([...Object.keys(base), ...Object.keys(local), ...Object.keys(remote)]);

  for (const key of keys) {
    if (META_FIELDS.has(key)) continue;
    const b = Object.prototype.hasOwnProperty.call(base, key) ? base[key] : undefined;
    const l = Object.prototype.hasOwnProperty.call(local, key) ? local[key] : undefined;
    const r = Object.prototype.hasOwnProperty.call(remote, key) ? remote[key] : undefined;
    const localChanged = !isDeepEqual(l, b);
    const remoteChanged = !isDeepEqual(r, b);

    if (!localChanged) continue;
    if (remoteChanged && !isDeepEqual(l, r)) {
      conflicts.push({ field: key, base: b, local: l, remote: r });
      continue;
    }
    if (Object.prototype.hasOwnProperty.call(local, key)) merged[key] = l;
    else delete merged[key];
  }
  return { merged, conflicts };
}

export function shortConflictSummary(conflicts = []) {
  return conflicts.map((c) => c.field).join(", ");
}
