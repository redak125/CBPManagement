import { collection, doc, onSnapshot, runTransaction, serverTimestamp, getDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { ChangeManager } from "./change-manager.js";

export const CURRENT_COLLECTIONS = [
  "client", "fournisseur", "appro", "prod_appro", "silo", "personnel", "materiel", "parametres",
  "prod", "recette", "depense", "transfert", "affect", "sousaff", "prod_fini", "facture", "regstock", "journal", "app_meta"
];

export class FirebaseCompanyRepository {
  constructor({ db, companyId, userId, userEmail, canWrite = false, draftStore }) {
    if (!db || !companyId || !userId || !draftStore) throw new TypeError("db, companyId, userId et draftStore sont obligatoires.");
    this.db = db;
    this.companyId = companyId;
    this.userId = userId;
    this.userEmail = userEmail ?? "";
    this.canWrite = canWrite === true;
    this.manager = new ChangeManager({ store: draftStore, scopeKey: `${companyId}:${this.userId}` });
    this.unsubscribers = [];
  }

  async restoreDraft() { return this.manager.restoreDraft(); }
  rows(table, options) { return this.manager.rows(table, options); }
  record(table, id) { return this.rows(table, { includeDeleted: true }).find((r) => r.id === id) ?? null; }
  newId(table) { return doc(collection(this.db, "entreprises", this.companyId, table)).id; }
  assertCanWrite() {
    if (!this.canWrite) throw new Error("Votre profil autorise uniquement la consultation.");
  }
  create(table, id, data) { this.assertCanWrite(); this.manager.create(table, id, data); }
  update(table, id, data) { this.assertCanWrite(); this.manager.update(table, id, data); }
  softDelete(table, id) { this.assertCanWrite(); this.manager.softDelete(table, id); }
  resolveConflict(table, id, choices) { this.assertCanWrite(); this.manager.resolveConflict(table, id, choices); }
  resolveStructuralConflict(table, id, choice, newId) { this.assertCanWrite(); this.manager.resolveStructuralConflict(table, id, choice, newId); }

  watch(tables = CURRENT_COLLECTIONS, { onUpdate = () => {}, onError = () => {} } = {}) {
    this.stopWatching();
    for (const table of tables) {
      const unsubscribe = onSnapshot(collection(this.db, "entreprises", this.companyId, table),
        (snapshot) => {
          const documents = new Map(snapshot.docs.map((item) => [item.id, item.data()]));
          this.manager.setRemoteTable(table, documents);
          onUpdate({ table, pendingRemoteWrites: snapshot.metadata.hasPendingWrites, hasLocalChanges: this.manager.isDirty() });
        }, onError);
      this.unsubscribers.push(unsubscribe);
    }
    return () => this.stopWatching();
  }

  async saveAll() {
    this.assertCanWrite();
    return this.manager.saveAll({
      db: this.db,
      companyId: this.companyId,
      userEmail: this.userEmail,
      firestore: { doc, runTransaction, serverTimestamp, getDoc }
    });
  }

  stopWatching() {
    for (const unsubscribe of this.unsubscribers.splice(0)) {
      try { unsubscribe(); } catch (error) { console.warn("Arrêt d'écoute Firestore :", error); }
    }
  }

  dispose() { this.stopWatching(); }
}
