/**
 * Règles financières recopiées de CBPManagement.java.
 * Les calculs sont faits en centimes BigInt afin de reproduire BigDecimal
 * avec RoundingMode.HALF_UP, y compris pour les valeurs négatives.
 */
function parseDecimal(value) {
  if (value === null || value === undefined || value === "") return { coefficient: 0n, scale: 0 };
  let s = String(value).trim().replace(/[\s\u00a0\u202f]/g, "").replace(",", ".");
  if (!s) return { coefficient: 0n, scale: 0 };
  const match = s.match(/^([+-]?)(\d*)(?:\.(\d*))?(?:[eE]([+-]?\d+))?$/);
  if (!match || (!match[2] && !match[3])) throw new TypeError(`Nombre invalide : ${value}`);
  const sign = match[1] === "-" ? -1n : 1n;
  const whole = match[2] || "0";
  const fraction = match[3] || "";
  const exponent = Number(match[4] || 0);
  if (!Number.isSafeInteger(exponent) || Math.abs(exponent) > 100) throw new RangeError("Exposant numérique hors limites.");
  let digits = `${whole}${fraction}`.replace(/^0+(?=\d)/, "") || "0";
  let scale = fraction.length - exponent;
  let coefficient = sign * BigInt(digits);
  if (scale < 0) { coefficient *= 10n ** BigInt(-scale); scale = 0; }
  if (scale > 100) throw new RangeError("Précision numérique hors limites.");
  return { coefficient, scale };
}

function roundHalfUp(numerator, denominator) {
  if (denominator <= 0n) throw new RangeError("Dénominateur invalide.");
  const negative = numerator < 0n;
  const absolute = negative ? -numerator : numerator;
  let quotient = absolute / denominator;
  const remainder = absolute % denominator;
  if (remainder * 2n >= denominator) quotient += 1n;
  return negative ? -quotient : quotient;
}

function toCents(value) {
  const d = parseDecimal(value);
  return roundHalfUp(d.coefficient * 100n, 10n ** BigInt(d.scale));
}
const fromCents = (cents) => Number(cents) / 100;
const sumCents = (rows, field) => rows.reduce((sum, row) => sum + toCents(row[field]), 0n);
const normalizedName = (value) => String(value ?? "").trim().toLocaleLowerCase("fr");

/** Équivalent de CBPManagement.amounts(Rec). */
export function calculateLineAmounts({ qte, pu, tva }, vatRate = 19) {
  const quantity = parseDecimal(qte);
  const unitPrice = parseDecimal(pu);
  const htCents = roundHalfUp(
    quantity.coefficient * unitPrice.coefficient * 100n,
    10n ** BigInt(quantity.scale + unitPrice.scale)
  );
  const appliesVat = tva === true || tva === 1 || tva === "1";
  const rate = appliesVat ? parseDecimal(vatRate) : { coefficient: 0n, scale: 0 };
  const vatCents = roundHalfUp(htCents * rate.coefficient, 100n * (10n ** BigInt(rate.scale)));
  return {
    taux: appliesVat ? Number(rate.coefficient) / (10 ** rate.scale) : 0,
    ht: fromCents(htCents),
    tvam: fromCents(vatCents),
    ttc: fromCents(htCents + vatCents)
  };
}

/** Net de recette = montant brut - remise. */
export function calculateReceiptNet({ montant, remise }) {
  return fromCents(toCents(montant) - toCents(remise));
}

/** Règles exactes de computeClientDebts() dans le code Java. */
export function calculateClientDebts({ clients = [], production = [], receipts = [], expenses = [] }) {
  const balances = new Map();
  const ensure = (name) => {
    const label = String(name ?? "").trim();
    const key = normalizedName(label);
    if (!key) return null;
    if (!balances.has(key)) balances.set(key, { name: label, billedCents: 0n, paidCents: 0n });
    return balances.get(key);
  };
  for (const row of clients) ensure(row.nom);
  for (const row of production) { const b = ensure(row.client); if (b) b.billedCents += toCents(row.ttc); }
  for (const row of receipts) { const b = ensure(row.debiteur); if (b) b.paidCents += toCents(row.montant); }
  for (const row of expenses) {
    if (row.aff !== "Remboursement client") continue;
    const b = ensure(row.sousaff);
    if (b) b.paidCents -= toCents(row.montant);
  }
  return [...balances.values()].map((x) => ({
    name: x.name, billed: fromCents(x.billedCents), paid: fromCents(x.paidCents),
    balance: fromCents(x.billedCents - x.paidCents)
  })).sort((a, b) => b.balance - a.balance);
}

/** Règles exactes de computeSupplierDebts() dans le code Java. */
export function calculateSupplierDebts({ suppliers = [], purchases = [], expenses = [] }) {
  const balances = new Map();
  const ensure = (name) => {
    const label = String(name ?? "").trim();
    const key = normalizedName(label);
    if (!key) return null;
    if (!balances.has(key)) balances.set(key, { name: label, purchasesCents: 0n, paidCents: 0n });
    return balances.get(key);
  };
  for (const row of suppliers) ensure(row.nom);
  for (const row of purchases) { const b = ensure(row.fournisseur); if (b) b.purchasesCents += toCents(row.ttc); }
  for (const row of expenses) {
    if (row.aff !== "Fournisseur") continue;
    const b = ensure(row.sousaff);
    if (b) b.paidCents += toCents(row.montant);
  }
  return [...balances.values()].map((x) => ({
    name: x.name, purchases: fromCents(x.purchasesCents), paid: fromCents(x.paidCents),
    balance: fromCents(x.purchasesCents - x.paidCents)
  })).sort((a, b) => b.balance - a.balance);
}

/** Équivalent de DashboardPanel.dispoAt : recettes nettes - dépenses, jusqu'à la date incluse. */
export function calculateAvailability(dateISO, receipts = [], expenses = []) {
  const income = sumCents(receipts.filter((r) => String(r.date ?? "") <= dateISO), "net");
  const outgoing = sumCents(expenses.filter((r) => String(r.date ?? "") <= dateISO), "montant");
  return fromCents(income - outgoing);
}

export function validateTransfer({ source, destination, montant }) {
  if (!source || !destination) return "Le compte source et le compte destination sont obligatoires.";
  if (source === destination) return "Les comptes source et destination doivent être différents.";
  if (toCents(montant) <= 0n) return "Le montant du transfert doit être supérieur à zéro.";
  return null;
}
