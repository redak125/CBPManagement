import test from "node:test";
import assert from "node:assert/strict";
import { buildLegacyReferenceIndexes, mapLegacyReferences } from "../web/src/import/reference-mapper.js";

test("convertit les références appro depuis les noms vers les IDs existants", () => {
  const remote = new Map([
    ["fournisseur", new Map([["f1", { nom: "Fournisseur A" }]])],
    ["prod_appro", new Map([["p1", { nature: "Matière première", nom: "Ciment" }]])],
    ["silo", new Map([["s1", { nom: "Silo 1" }]])]
  ]);
  const indexes = buildLegacyReferenceIndexes({ tables: {} }, remote, []);
  const result = mapLegacyReferences("appro", {
    nature: "Matière première", fournisseur: "Fournisseur A", produit: "Ciment", silo: "Silo 1"
  }, indexes);
  assert.deepEqual(result.row, {
    nature: "Matière première", fournisseur: "f1", produit: "p1", silo: "s1"
  });
  assert.deepEqual(result.review, []);
});

test("ne choisit pas arbitrairement entre deux clients homonymes", () => {
  const remote = new Map([["client", new Map([
    ["c1", { nom: "Client A" }], ["c2", { nom: "Client A" }]
  ])]]);
  const indexes = buildLegacyReferenceIndexes({ tables: {} }, remote, []);
  const result = mapLegacyReferences("recette", { debiteur: "Client A" }, indexes);
  assert.equal(result.row.debiteur, "Client A");
  assert.equal(result.review[0].status, "ambiguous");
  assert.deepEqual(result.review[0].candidateIds.sort(), ["c1", "c2"]);
});

test("mappe une dépense fournisseur vers le document fournisseur", () => {
  const remote = new Map([
    ["affect", new Map([["af1", { nom: "Fournisseur" }]])],
    ["fournisseur", new Map([["f1", { nom: "Fournisseur A" }]])]
  ]);
  const indexes = buildLegacyReferenceIndexes({ tables: {} }, remote, []);
  const result = mapLegacyReferences("depense", {
    aff: "Fournisseur", sousaff: "Fournisseur A", benef: "Comptabilité"
  }, indexes);
  assert.equal(result.row.aff, "af1");
  assert.equal(result.row.sousaff, "f1");
  assert.equal(result.row.benef, "Comptabilité");
  assert.deepEqual(result.review, []);
});
