import test from "node:test";
import assert from "node:assert/strict";
import { buildLegacyMigrationPlan, mapMigrationPlanReferences, toFirestoreMigrationDocument } from "../web/src/import/migration-plan.js";

test("prépare un plan en lecture seule et identifie un doublon de source", async () => {
  const parsed = { format: "CBPM-binary", version: 2, tables: {
    client: [{ nom: "Client A", tel: "111" }, { nom: "Client A", tel: "222" }],
    param: [{ tva: "19" }]
  } };
  const plan = await buildLegacyMigrationPlan(parsed);
  assert.equal(plan.summary.create, 1);
  assert.equal(plan.summary["duplicate-in-source"], 1);
  assert.ok(plan.warnings.some((w) => w.includes("paramètres Java")));
  assert.throws(() => toFirestoreMigrationDocument(plan.items[1]));
  assert.equal(toFirestoreMigrationDocument(plan.items[0]).origineMigration, "CBPM-Java");
});

test("convertit les références avant de proposer une nouvelle ligne", async () => {
  const parsed = { format: "CBPM-binary", version: 2, tables: {
    fournisseur: [{ nom: "Fournisseur A" }],
    prod_appro: [{ nature: "Matière première", nom: "Ciment" }],
    silo: [{ nom: "Silo 1" }],
    appro: [{ nature: "Matière première", fournisseur: "Fournisseur A", produit: "Ciment", silo: "Silo 1", qte: "10", pu: "250", tva: "1" }]
  } };
  const plan = await buildLegacyMigrationPlan(parsed);
  const mapped = mapMigrationPlanReferences(plan, parsed);
  const appro = mapped.items.find((item) => item.table === "appro");
  assert.equal(appro.action, "create");
  assert.equal(typeof appro.sourceMapped.qte, "number");
  assert.equal(appro.sourceMapped.tva, true);
  assert.equal(appro.sourceMapped.fournisseur.startsWith("legacy_"), true);
  assert.equal(appro.sourceMapped.produit.startsWith("legacy_"), true);
  assert.equal(appro.sourceMapped.silo.startsWith("legacy_"), true);
  assert.deepEqual(appro.referenceReview, []);
});
