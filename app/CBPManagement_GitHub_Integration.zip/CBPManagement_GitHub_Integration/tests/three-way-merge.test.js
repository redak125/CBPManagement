import test from "node:test";
import assert from "node:assert/strict";
import { isDeepEqual, mergeThreeWay, cleanFirestoreDocument } from "../web/src/data/three-way-merge.js";

test("fusionne des modifications faites sur des champs différents", () => {
  const result = mergeThreeWay(
    { nom: "Client A", tel: "111", adr: "Rue 1" },
    { nom: "Client A", tel: "222", adr: "Rue 1" },
    { nom: "Client A", tel: "111", adr: "Rue 2" }
  );
  assert.deepEqual(result.conflicts, []);
  assert.deepEqual(result.merged, { nom: "Client A", tel: "222", adr: "Rue 2" });
});

test("signale un conflit lorsque les deux côtés modifient le même champ", () => {
  const result = mergeThreeWay({ tel: "111" }, { tel: "222" }, { tel: "333" });
  assert.equal(result.conflicts.length, 1);
  assert.equal(result.conflicts[0].field, "tel");
  assert.equal(result.merged.tel, "333"); // la valeur distante reste intacte en attendant une décision
});

test("respecte les suppressions de propriétés", () => {
  const result = mergeThreeWay({ note: "à conserver", tel: "111" }, { tel: "222" }, { note: "à conserver", tel: "111" });
  assert.equal(Object.hasOwn(result.merged, "note"), false);
  assert.equal(result.merged.tel, "222");
});

test("ignore les métadonnées de version lors des comparaisons métier", () => {
  assert.deepEqual(cleanFirestoreDocument({ id: "x", version: 3, majPar: "admin", majLe: "date", nom: "A" }), { nom: "A" });
  assert.equal(isDeepEqual({ x: 1, version: 1 }, { x: 1, version: 2 }), false);
  assert.equal(isDeepEqual(cleanFirestoreDocument({ x: 1, version: 1 }), cleanFirestoreDocument({ x: 1, version: 2 })), true);
});
