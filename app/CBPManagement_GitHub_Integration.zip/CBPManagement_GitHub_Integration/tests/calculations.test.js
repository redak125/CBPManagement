import test from "node:test";
import assert from "node:assert/strict";
import {
  calculateLineAmounts, calculateReceiptNet, calculateClientDebts,
  calculateSupplierDebts, calculateAvailability, validateTransfer
} from "../web/src/domain/calculations.js";

test("calcule HT, TVA et TTC comme BigDecimal HALF_UP", () => {
  assert.deepEqual(calculateLineAmounts({ qte: "3", pu: "12,345", tva: "1" }, "19"), {
    taux: 19, ht: 37.04, tvam: 7.04, ttc: 44.08
  });
  assert.deepEqual(calculateLineAmounts({ qte: "1", pu: "-1,005", tva: "0" }), {
    taux: 0, ht: -1.01, tvam: 0, ttc: -1.01
  });
});

test("calcule le net d'une recette", () => {
  assert.equal(calculateReceiptNet({ montant: "125,50", remise: "5,25" }), 120.25);
});

test("reproduit les dettes clients avec remboursements", () => {
  const rows = calculateClientDebts({
    clients: [{ nom: "Client A" }],
    production: [{ client: "Client A", ttc: "1000" }],
    receipts: [{ debiteur: "Client A", montant: "400" }],
    expenses: [{ aff: "Remboursement client", sousaff: "Client A", montant: "50" }]
  });
  assert.deepEqual(rows[0], { name: "Client A", billed: 1000, paid: 350, balance: 650 });
});

test("reproduit les dettes fournisseurs", () => {
  const rows = calculateSupplierDebts({
    suppliers: [{ nom: "Fournisseur A" }],
    purchases: [{ fournisseur: "Fournisseur A", ttc: "800" }],
    expenses: [{ aff: "Fournisseur", sousaff: "Fournisseur A", montant: "300" }]
  });
  assert.deepEqual(rows[0], { name: "Fournisseur A", purchases: 800, paid: 300, balance: 500 });
});

test("calcule la trésorerie sur les recettes nettes moins les dépenses", () => {
  assert.equal(calculateAvailability("2026-11-26", [
    { date: "2026-11-26", net: "100" }, { date: "2026-11-27", net: "80" }
  ], [{ date: "2026-11-25", montant: "25" }]), 75);
});

test("valide les transferts", () => {
  assert.equal(validateTransfer({ source: "Caisse", destination: "Banque", montant: "10" }), null);
  assert.match(validateTransfer({ source: "Caisse", destination: "Caisse", montant: "10" }), /différents/);
  assert.match(validateTransfer({ source: "Caisse", destination: "Banque", montant: "0" }), /supérieur à zéro/);
});
