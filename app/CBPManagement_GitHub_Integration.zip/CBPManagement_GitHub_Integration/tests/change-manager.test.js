import test from "node:test";
import assert from "node:assert/strict";
import { ChangeManager } from "../web/src/data/change-manager.js";

class MemoryDraftStore {
  values = new Map();
  async read(key) { return structuredClone(this.values.get(key) ?? []); }
  async write(key, changes) { this.values.set(key, structuredClone(changes)); }
  async remove(key) { this.values.delete(key); }
}

function fakeFirestore(seed = {}) {
  const documents = new Map(Object.entries(seed));
  const doc = (_db, ...parts) => ({ path: parts.join("/") });
  const snapshot = (data) => ({ exists: () => data !== undefined, data: () => structuredClone(data) });
  const firestore = {
    doc,
    serverTimestamp: () => "SERVER_TIME",
    getDoc: async (ref) => snapshot(documents.get(ref.path)),
    runTransaction: async (_db, callback) => {
      const writes = [];
      const tx = {
        get: async (ref) => snapshot(documents.get(ref.path)),
        set: (ref, data) => writes.push([ref.path, structuredClone(data)])
      };
      const result = await callback(tx);
      for (const [path, data] of writes) documents.set(path, data);
      return result;
    },
    documents
  };
  return firestore;
}

test("les modifications restent locales jusqu'à saveAll", async () => {
  const store = new MemoryDraftStore();
  const manager = new ChangeManager({ store, scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map());
  manager.create("client", "new-1", { nom: "Client local" });
  await manager.persistQueue;
  assert.equal(manager.isDirty(), true);
  assert.equal(store.values.get("company:user").length, 1);
});

test("fusionne au moment de sauvegarder si Firebase a changé un autre champ", async () => {
  const store = new MemoryDraftStore();
  const manager = new ChangeManager({ store, scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", tel: "111", adr: "Rue 1", version: 1 }]]));
  manager.update("client", "c1", { tel: "222" });
  const fs = fakeFirestore({ "entreprises/e1/client/c1": { nom: "Client A", tel: "111", adr: "Rue 2", version: 2 } });
  const summary = await manager.saveAll({ db: {}, companyId: "e1", userEmail: "admin@test", firestore: fs });
  const saved = fs.documents.get("entreprises/e1/client/c1");
  assert.equal(summary.saved, 1);
  assert.equal(saved.tel, "222");
  assert.equal(saved.adr, "Rue 2");
  assert.equal(manager.isDirty(), false);
});

test("ne remplace pas une valeur distante modifiée sur le même champ", async () => {
  const store = new MemoryDraftStore();
  const manager = new ChangeManager({ store, scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", tel: "111", version: 1 }]]));
  manager.update("client", "c1", { tel: "222" });
  const fs = fakeFirestore({ "entreprises/e1/client/c1": { nom: "Client A", tel: "333", version: 2 } });
  const summary = await manager.saveAll({ db: {}, companyId: "e1", userEmail: "admin@test", firestore: fs });
  assert.equal(summary.conflicts.length, 1);
  assert.equal(fs.documents.get("entreprises/e1/client/c1").tel, "333");
  assert.equal(manager.isDirty(), true);
});

test("une suppression est un marqueur deleted et non un DELETE physique", async () => {
  const store = new MemoryDraftStore();
  const manager = new ChangeManager({ store, scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", version: 1 }]]));
  manager.softDelete("client", "c1");
  const fs = fakeFirestore({ "entreprises/e1/client/c1": { nom: "Client A", version: 1 } });
  const summary = await manager.saveAll({ db: {}, companyId: "e1", userEmail: "admin@test", firestore: fs });
  assert.equal(summary.saved, 1);
  assert.equal(fs.documents.get("entreprises/e1/client/c1").deleted, true);
});

test("conserve une nouvelle saisie effectuée pendant une sauvegarde", async () => {
  const store = new MemoryDraftStore();
  const manager = new ChangeManager({ store, scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", tel: "111", version: 1 }]]));
  manager.update("client", "c1", { tel: "222" });

  let allowCommit;
  let transactionPrepared;
  const prepared = new Promise((resolve) => { transactionPrepared = resolve; });
  const gate = new Promise((resolve) => { allowCommit = resolve; });
  const documents = new Map([["entreprises/e1/client/c1", { nom: "Client A", tel: "111", version: 1 }]]);
  const firestore = {
    doc: (_db, ...parts) => ({ path: parts.join("/") }),
    serverTimestamp: () => "SERVER_TIME",
    getDoc: async (ref) => ({ exists: () => documents.has(ref.path), data: () => structuredClone(documents.get(ref.path)) }),
    runTransaction: async (_db, callback) => {
      const writes = [];
      const result = await callback({
        get: async (ref) => ({ exists: () => documents.has(ref.path), data: () => structuredClone(documents.get(ref.path)) }),
        set: (ref, data) => writes.push([ref.path, structuredClone(data)])
      });
      transactionPrepared();
      await gate;
      for (const [path, data] of writes) documents.set(path, data);
      return result;
    },
    documents
  };

  const saving = manager.saveAll({ db: {}, companyId: "e1", userEmail: "admin@test", firestore });
  await prepared;
  manager.update("client", "c1", { tel: "333" });
  allowCommit();
  const firstSummary = await saving;
  assert.equal(firstSummary.saved, 1);
  assert.equal(manager.isDirty(), true);
  assert.equal(manager.rows("client")[0].tel, "333");

  const secondSummary = await manager.saveAll({ db: {}, companyId: "e1", userEmail: "admin@test", firestore });
  assert.equal(secondSummary.saved, 1);
  assert.equal(documents.get("entreprises/e1/client/c1").tel, "333");
  assert.equal(manager.isDirty(), false);
});

test("résout un conflit de création par duplication sous un nouvel identifiant", async () => {
  const manager = new ChangeManager({ store: new MemoryDraftStore(), scopeKey: "company:user" });
  manager.create("client", "same-id", { nom: "Client local" });
  manager.setRemoteTable("client", new Map([["same-id", { nom: "Client distant", version: 1 }]]));
  manager.resolveStructuralConflict("client", "same-id", "duplicate-local", "local-copy");
  assert.equal(manager.isDirty(), true);
  assert.equal(manager.rows("client").find((r) => r.id === "same-id").nom, "Client distant");
  assert.equal(manager.rows("client").find((r) => r.id === "local-copy").nom, "Client local");
});

test("signale une suppression logique distante et permet une restauration explicite", async () => {
  const manager = new ChangeManager({ store: new MemoryDraftStore(), scopeKey: "company:user" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", tel: "111", version: 1 }]]));
  manager.update("client", "c1", { tel: "222" });
  manager.setRemoteTable("client", new Map([["c1", { nom: "Client A", tel: "111", deleted: true, version: 2 }]]));
  assert.equal(manager.conflicts().length, 1);
  manager.resolveStructuralConflict("client", "c1", "restore-local");
  const row = manager.rows("client").find((x) => x.id === "c1");
  assert.equal(row.deleted, false);
  assert.equal(row.tel, "222");
  assert.equal(row._conflict, false);
});
