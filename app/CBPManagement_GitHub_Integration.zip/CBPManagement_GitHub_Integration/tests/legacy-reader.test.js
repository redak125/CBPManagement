import test from "node:test";
import assert from "node:assert/strict";
import { gzipSync } from "node:zlib";
import { readLegacyCbpm } from "../web/src/import/legacy-cbpm-reader.js";

const i32 = (value) => { const b = Buffer.alloc(4); b.writeInt32BE(value); return b; };
const string = (value) => { const b = Buffer.from(value, "utf8"); return Buffer.concat([i32(b.length), b]); };

test("lit le format CBPM binaire version 2 écrit par Java", async () => {
  const raw = Buffer.concat([
    Buffer.from("CBPM"), Buffer.from([2]), i32(1), string("client"), i32(1), i32(2),
    string("nom"), string("Client Test"), string("tel"), string("0550123456")
  ]);
  const file = new Blob([gzipSync(raw)], { type: "application/gzip" });
  const parsed = await readLegacyCbpm(file);
  assert.equal(parsed.format, "CBPM-binary");
  assert.equal(parsed.version, 2);
  assert.deepEqual(parsed.tables.client, [{ nom: "Client Test", tel: "0550123456" }]);
});

test("lit le format texte .cbpm historique", async () => {
  const file = new Blob(["#CBPM\nclient\tnom=Client\\tA\ttel=0550123456\n"], { type: "text/plain" });
  const parsed = await readLegacyCbpm(file);
  assert.equal(parsed.format, "CBPM-text");
  assert.equal(parsed.tables.client[0].nom, "Client\tA");
});
