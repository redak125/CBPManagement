# CBPManagement — paquet à ajouter au dépôt GitHub existant

Ce paquet est organisé pour le dépôt `redak125/CBPManagement` tel qu'il apparaît dans la capture :

- le point d'entrée Web existant reste `app/index.html` ;
- le `index.html` à la racine du dépôt n'est pas modifié ;
- le `README.md` existant à la racine n'est pas remplacé ;
- les fichiers Android et les images existants ne sont pas modifiés.

## Installation

À partir de la racine du dépôt GitHub, ajouter les éléments de cette archive en conservant exactement leurs chemins :

- `app/src/` : nouveaux modules JavaScript ;
- `docs/` : documentation de migration ;
- `tests/` : tests automatisés ;
- `package.json` : commande de tests ;
- `README-MIGRATION.md` : documentation de ce paquet, sans écraser le README actuel.

La structure résultante est :

```text
CBPManagement/
├── app/
│   ├── index.html                 # conserver le fichier actuel
│   └── src/                       # nouveaux modules préparés
│       ├── auth/
│       ├── data/
│       ├── domain/
│       ├── import/
│       ├── modules/
│       └── ui/
├── docs/
├── tests/
├── package.json
├── README-MIGRATION.md
├── index.html                     # conserver le fichier racine
├── README.md                      # conserver le fichier racine
└── ...                            # fichiers APK et images existants
```

## Vérifier les tests

Depuis la racine du dépôt, avec Node.js 20 ou supérieur :

```bash
npm test
```

## Important : les modules ne sont pas encore branchés

L'ajout de ces fichiers ne change pas le comportement de l'application. `app/index.html` reste inchangé. L'intégration fonctionnelle se fera ensuite en plusieurs modifications contrôlées :

1. initialisation du gestionnaire local après authentification ;
2. remplacement des appels CRUD qui écrivent directement dans Firestore ;
3. bouton global Enregistrer et gestion des conflits ;
4. dialogue de sortie et reprise des brouillons ;
5. migration des modules métier et recette avec les données réelles.

Ne déployer aucune écriture Firebase issue de ces modules avant d'avoir branché et testé les règles de sécurité Firestore et les permissions réelles.
