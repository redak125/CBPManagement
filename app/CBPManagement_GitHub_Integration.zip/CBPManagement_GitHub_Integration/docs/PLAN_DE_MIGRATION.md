# Plan d'exécution de la migration complète

## Phase 0 — Geler et sauvegarder les sources

- conserver une copie intacte du Java actuel ;
- sauvegarder toutes les collections de l'entreprise dans le projet Web `cbpm-8ac0e` ;
- obtenir le fichier `.cbpm` actuellement utilisé par l'entreprise ;
- exporter les règles Firestore et les paramètres de déploiement ;
- identifier les comptes Web réels, les rôles et les entreprises ;
- conserver séparément les sauvegardes historiques `CBPM-Daily-v1` du projet Java.

Aucune migration réelle ne peut être exécutée à partir du seul fichier source `.java` : il faut le fichier de données `.cbpm` de l'entreprise et une lecture contrôlée des collections existantes.

## Phase 1 — Stabiliser l'identité et la sécurité

- réutiliser le projet Web existant ;
- garder les utilisateurs Firebase Authentication et les documents `utilisateurs/{uid}` ;
- vérifier les rôles et rattachements à l'entreprise ;
- obtenir et tester les règles Firestore ;
- ne pas importer directement les comptes Java locaux ni leurs hashes.

## Phase 2 — Terminer la couche de données

- brancher `FirebaseCompanyRepository` à l'initialisation Firebase existante ;
- remplacer chaque appel immédiat à `ecrire()` par une modification dans `ChangeManager` ;
- installer IndexedDB et la reprise de brouillon ;
- ajouter le bouton global **Enregistrer** et le dialogue de sortie ;
- ajouter l'écran de conflits et ses choix ;
- tester les transactions, les pannes réseau, les modifications simultanées et les sauvegardes partielles ;
- ajouter des groupes atomiques pour les opérations métiers qui modifient plusieurs documents en une seule action.

## Phase 3 — Porter les écrans Java dans cet ordre

1. Référentiels : clients, fournisseurs, personnel, matériels, produits d'approvisionnement, produits finis, silos, affectations et sous-affectations.
2. Activité : approvisionnements/services, production/services et régularisation du stock.
3. Finances : recettes, dépenses, transferts, factures, dettes clients et dettes fournisseurs.
4. Pilotage : tableau de bord, contrôle de gestion, rapports, graphiques et journal des opérations.
5. Administration : paramètres, utilisateurs, rôles et messagerie sécurisée.

Chaque écran doit reprendre les champs, validations, tris, filtres, totaux et actions de la version Java. Les dépendances entre fiches doivent utiliser les IDs Firestore, jamais le libellé comme identifiant permanent.

## Phase 4 — Portage des fonctions transversales

- import/export `.xlsx` et formats de rapports ;
- impression et génération PDF : factures, bons de livraison, versements et paiements ;
- annuler/rétablir ;
- journal d'audit ;
- sauvegarde/restauration et récupération ;
- aide et documentation ;
- français/anglais/arabe, polices adaptées et tests RTL sur tous les écrans ;
- thèmes clair/sombre ;
- décision explicite sur la continuité de l'intégration Android historique.

Le lecteur `.cbpm` fourni ici n'est qu'une première brique d'import ; la création complète du parcours d'import/export et de reprise n'est pas terminée.

## Phase 5 — Import contrôlé des données

1. sélectionner le fichier `.cbpm` réel et le lire localement ;
2. charger les collections déjà présentes dans le projet Web ;
3. produire un rapport de comparaison en lecture seule ;
4. contrôler les lignes déjà présentes, différentes, ambiguës et dupliquées ;
5. convertir les références Java en IDs Firestore ;
6. résoudre manuellement les références ou doublons ambigus ;
7. valider un import pilote sur une entreprise de test ;
8. vérifier les totaux, les stocks, les dettes et les factures par rapport au Java ;
9. sauvegarder à nouveau les données avant la migration de production ;
10. importer uniquement les nouvelles lignes confirmées et conserver un marqueur d'import idempotent.

Le convertisseur `reference-mapper.js` fournit une base stricte pour les relations identifiées ; il ne remplace pas la revue des relations des données réelles.

## Phase 6 — Recette avant bascule

- utilisateur administrateur : création, modification, suppression logique, sauvegarde et gestion des comptes ;
- utilisateur consultation : aucune modification possible, y compris en appelant directement les fonctions de l'interface ;
- deux utilisateurs sur le même document : modifications de champs différents fusionnées ; même champ différent signalé comme conflit ;
- onglet fermé puis réouvert : brouillon récupéré ;
- sortie interne : les trois choix fonctionnent ;
- perte réseau : aucun message « sauvegardé » prématuré ; reprise après connexion ;
- import en doublon : pas de doublon créé ;
- impression, PDF, Excel et rapports comparés aux documents Java ;
- interface française, anglaise et arabe vérifiée à plusieurs tailles d'écran ;
- règles Firestore testées avec comptes de chaque rôle.

## Phase 7 — Bascule

- choisir une fenêtre de bascule ;
- faire une dernière sauvegarde du dossier Java et des collections Web ;
- importer les nouvelles lignes avec rapport signé ;
- désactiver les écritures sur l'ancienne application si elle ne doit plus être utilisée ;
- garder une sauvegarde exportable et un plan de retour arrière ;
- surveiller les conflits, erreurs réseau et journaux après ouverture.

## Critères d'acceptation

La migration n'est complète que lorsque tous les écrans et fonctions de l'inventaire sont présents, que les totaux sont identiques au Java pour un jeu de données de référence, que l'import peut être relancé sans dupliquer les lignes, que les rôles sont imposés par les règles Firebase, et que les 3 scénarios de fusion (champ indépendant, même champ, suppression concurrente) sont testés dans un vrai projet de recette.
