# État du livrable au 26 novembre 2026

## Réalisé dans ce dossier

- architecture de sauvegarde différée et stockage local IndexedDB ;
- fusion à trois états par champ ;
- transactions Firestore au moment de la sauvegarde ;
- détection des conflits de même champ, des suppressions distantes et des collisions d'identifiants ;
- méthodes de résolution des conflits de champs et des conflits structurels ;
- bouton global Enregistrer et garde de sortie avec dialogue interne ;
- réutilisation du profil Firebase Web existant et contrôle `admin` / lecture seule ;
- inventaire des modules et collections cibles ;
- formules financières fondamentales recopiées du Java avec arrondi décimal `HALF_UP` ;
- lecteur `.cbpm` texte historique et binaire/gzip version 2 ;
- plan de migration en lecture seule ;
- conversion de références connues du modèle Java par libellé vers les IDs Firestore ;
- documentation sécurité, identité, schéma et feuille de route ;
- 24 tests automatisés verts.

## Non réalisé dans ce dossier

- remplacement complet de l'interface HTML actuelle par l'ensemble des 20 écrans Java ;
- formulaires, tableaux, filtres et validations détaillés de chaque module métier ;
- traduction exhaustive FR/EN/AR, tests RTL et finitions responsive ;
- portage complet de la production, du stock, de la facturation, du contrôle de gestion et de tous les rapports ;
- génération complète des factures, bons PDF et rapports imprimables ;
- import/export Excel complet ;
- annuler/rétablir de toutes les opérations dans l'interface Web ;
- messagerie avec backend SMTP/IMAP sécurisé ;
- récupération et restauration complète ;
- portage complet de l'administration des utilisateurs Java ;
- transactions atomiques multi-documents pour tous les scénarios métier ;
- audit des règles Firestore réelles et essai de bout en bout sur le projet Firebase ;
- import effectif du fichier de données `.cbpm` de l'entreprise.

## Pourquoi ces éléments restent séparés

Les fichiers fournis sont le code Java et le prototype Web ; ils ne contiennent pas le dossier de données réel `.cbpm` de l'entreprise ni les règles de sécurité Firestore. En outre, le prototype Web et les sauvegardes Java utilisent deux projets Firebase et deux modèles d'identité différents. Faire comme si toutes ces informations étaient déjà compatibles pourrait provoquer une perte de données ou une perte d'accès.

Le paquet livre donc le socle préparatoire et les règles de migration vérifiées, sans écrire dans Firebase ni prétendre que l'application complète est déjà terminée.
