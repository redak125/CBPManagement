# Inventaire fonctionnel — comparaison des deux sources

## 1. État du prototype Web fourni

Le prototype Web est un HTML autonome en français qui utilise Firebase JS SDK 10.14.1. Il authentifie l'utilisateur avec Firebase Authentication, lit `utilisateurs/{uid}`, puis charge `entreprises/{entrepriseId}`. Il vérifie l'état suspendu de l'entreprise et utilise `role === "admin"` pour autoriser les modifications.

Collections écoutées dans ce prototype :

- `client`
- `fournisseur`
- `appro`
- `prod_appro`
- `silo`
- `personnel`
- `materiel`
- `parametres`

Écrans déjà présents : clients, fournisseurs, approvisionnements/services, personnel, matériels, paramètres ; les produits d'approvisionnement et les silos sont ouverts dans des fenêtres secondaires. Le prototype sait ajouter, modifier, marquer une ligne supprimée, filtrer, trier, calculer les totaux affichés et imprimer une liste. Ses écritures passent immédiatement par `runTransaction` dans `ecrire()`.

## 2. Modules présents dans la version Java à porter

| Groupe | Écran / fonction Java | Données principales | État dans le prototype Web fourni |
|---|---|---|---|
| Gestion | Tableau de bord | production, appro, recettes, dépenses, transferts, stock | absent |
| Gestion | Clients | `client` | présent, à raccorder à la sauvegarde différée |
| Gestion | Fournisseurs | `fournisseur` | présent, à raccorder à la sauvegarde différée |
| Gestion | Approvisionnements et services | `appro`, `prod_appro`, `silo` | partiel |
| Gestion | Production et services | `prod`, `prod_fini`, `silo`, `materiel`, `personnel` | absent |
| Gestion | Régularisation du stock | `regstock`, approvisionnements, production | absent |
| Finances | Facturation | `facture`, `prod`, `client` | absent |
| Finances | Recettes | `recette` | absent |
| Finances | Dépenses | `depense`, `affect`, `sousaff` | absent |
| Finances | Transferts de trésorerie | `transfert` | absent |
| Finances | Dettes clients | calculées depuis `prod`, `recette`, `depense`, `client` | absent |
| Finances | Dettes fournisseurs | calculées depuis `appro`, `depense`, `fournisseur` | absent |
| Finances | Contrôle de gestion | données financières, ventes, achats, dettes et stock | absent |
| Ressources | Personnel | `personnel` | présent |
| Ressources | Matériels | `materiel` | présent |
| Ressources | Messagerie | `mailcfg` et service de messagerie | absent |
| Système | Paramètres | paramètres société, TVA, orientation, marges, etc. | partiel ; le prototype possède `parametres/general` |
| Système | Rapports | données de plusieurs collections | absent |
| Système | Journal des opérations | `journal` | absent |
| Système | Gestion des utilisateurs | comptes et rôles | authentification existante, interface d'administration à porter |

## 3. Fonctions transversales à préserver

Le Java contient aussi les fonctions suivantes, qui ne sont pas des écrans CRUD ordinaires :

- création d'un nouveau dossier de travail, ouverture, enregistrement et enregistrement sous ;
- importation et exportation Excel (`.xlsx`) ;
- lecture et écriture du format `.cbpm` ;
- aperçu et impression de factures, bons de livraison, bons de versement et bons de paiement ;
- rapports imprimables, états clients/fournisseurs et contrôle de gestion ;
- annuler/rétablir avec historique ;
- sauvegarde et restauration, récupération locale ;
- journalisation des opérations et des changements ;
- gestion des accès utilisateurs ;
- français, anglais et arabe, avec traitement de l'interface RTL ;
- thèmes clair/sombre ;
- paramètres d'accès Android présents dans la version Java ; leur maintien devra être validé si l'application Android compagnon reste utilisée.

La messagerie Java utilise une configuration locale et des échanges SMTP/IMAP. Son portage Web devra passer par un service sécurisé côté serveur ; les secrets SMTP/IMAP ne doivent pas être placés dans le JavaScript du navigateur ni dans Firestore en clair.

## 4. Tables Java et cible Firestore

La constante Java `TABLES` déclare `param`, `app_meta`, `affect`, `sousaff`, `client`, `fournisseur`, `appro`, `prod`, `recette`, `depense`, `transfert`, `personnel`, `materiel`, `prod_appro`, `silo`, `prod_fini`, `facture`, `regstock` et `journal`.

Dans le fichier `.cbpm` récent, `writeFile()` retire explicitement `param` et `mailcfg` : ces deux éléments sont stockés séparément des données du dossier. Les 18 tables métier restantes sont les données source à importer. Les écrans de dettes clients et fournisseurs sont des vues calculées, pas des tables source indépendantes.

Cible de données proposée sous le chemin Web existant :

`entreprises/{entrepriseId}/{collection}/{documentId}`

Collections de société : les 18 tables métier ci-dessus, plus `parametres` déjà utilisé par le prototype Web. Les comptes restent sous `utilisateurs/{uid}` et ne doivent pas être déplacés dans les collections métier.

## 5. Règles métier vérifiées dans le code Java

- Montant HT : quantité × prix unitaire, arrondi à deux décimales en `HALF_UP`.
- TVA : taux issu des paramètres si `tva == "1"`, sinon zéro ; TVA arrondie à deux décimales en `HALF_UP`.
- TTC : HT + TVA.
- Net d'une recette : montant − remise.
- Dettes clients : total TTC de `prod` − recettes brutes `recette.montant` + remboursements client saisis dans `depense` avec affectation `Remboursement client`.
- Dettes fournisseurs : total TTC de `appro` − dépenses affectées à `Fournisseur`.
- Disponibilité de trésorerie du tableau de bord : recettes nettes `recette.net` − dépenses `depense.montant` jusqu'à la date incluse. La méthode `dispoAt()` ne déduit pas les transferts.
- Un transfert exige deux comptes différents et un montant strictement positif.
- Une opération de production déjà facturée ne doit pas être modifiée ou supprimée sans traiter d'abord sa facture.
- Des suppressions de clients, fournisseurs, matériels et autres référentiels sont bloquées lorsqu'ils sont encore utilisés par des opérations liées.

Ces règles doivent être portées et testées sur des données d'exemple avant la mise en production.

## 6. Références entre lignes : point critique

Le Java stocke plusieurs relations sous forme de libellés (nom de client, fournisseur, produit, silo, chauffeur ou immatriculation). Le Web fourni utilise déjà des IDs Firestore pour les listes liées, par exemple `appro.fournisseur`, `appro.produit` et `appro.silo`.

La migration ne doit donc pas simplement copier ces valeurs. `reference-mapper.js` prépare les conversions exactes connues et marque les références absentes ou ambiguës pour revue. Les homonymes ne sont jamais résolus automatiquement. Les règles restant à confirmer pour les modules absents du prototype devront être validées avec les écrans cibles, notamment les dépenses, les factures et les sous-affectations.
