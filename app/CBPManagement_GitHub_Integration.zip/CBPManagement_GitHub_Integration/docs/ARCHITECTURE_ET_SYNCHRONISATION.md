# Architecture Web et sauvegarde différée

## 1. Flux cible

```text
Firebase Authentication existant
          │
          ▼
utilisateurs/{uid} ──► entreprises/{entrepriseId}
          │
          ▼
Écoute Firestore en lecture / snapshots distants
          │
          ▼
Copie de travail dans l'application
          │
          ├── Création / modification / suppression logique
          │          │
          │          ▼
          │     IndexedDB (brouillon local persistant)
          │
          └── Clic « Enregistrer » ou confirmation de sortie
                     │
                     ▼
          Relecture de la dernière version Firestore
                     │
                     ▼
          Fusion à trois états par document et par champ
                     │
          ┌──────────┴──────────┐
          ▼                     ▼
      Sans conflit          Conflit réel
          │                     │
          ▼                     ▼
      Transaction          Aucune écriture pour
      Firestore            le document concerné
          │                     │
          ▼                     ▼
      Version + audit       Résolution par l'utilisateur
```

## 2. Règle d'or : aucune écriture lors de la saisie

Les formulaires modifient uniquement la copie de travail. L'action locale **Ajouter / Modifier / Supprimer** d'un module crée une opération en attente dans `ChangeManager` ; cette action ne contacte pas Firebase. Le bouton global **Enregistrer** envoie ensuite les opérations en attente. La classe `ChangeManager` conserve ces opérations et les persiste dans IndexedDB. Les snapshots Firestore alimentent la copie distante et permettent de détecter les changements concurrents, mais ne provoquent pas d'écriture métier.

Les seuls déclencheurs d'écriture métier prévus sont :

1. clic explicite sur le bouton global **Enregistrer** ;
2. clic sur **Enregistrer et quitter** dans le dialogue de sortie.

**Quitter sans enregistrer** conserve le brouillon IndexedDB pour proposer sa reprise à la prochaine connexion. Le bouton de déconnexion doit passer par le même garde de sortie.

## 3. Fusion à trois états

Pour un document, on compare :

- `base` : dernière version commune connue ;
- `local` : version modifiée par l'utilisateur, non encore enregistrée ;
- `remote` : dernière version réellement présente dans Firestore au moment de l'enregistrement.

Exemple sans conflit :

| Champ | Base | Local | Firebase | Résultat |
|---|---|---|---|---|
| téléphone | 0550 | 0660 | 0550 | 0660 |
| adresse | Rue A | Rue A | Rue B | Rue B |

Les deux modifications sont réunies parce qu'elles portent sur des champs différents.

Exemple avec conflit :

| Champ | Base | Local | Firebase | Résultat |
|---|---|---|---|---|
| téléphone | 0550 | 0660 | 0770 | conflit |

Le document n'est pas écrit tant qu'un utilisateur n'a pas choisi la valeur à conserver. Les autres champs non conflictuels restent fusionnables.

## 4. Versionnement Firestore

Les documents conservent les métadonnées déjà employées par le Web :

- `version` : entier incrémenté à chaque écriture ;
- `majPar` : e-mail de l'utilisateur connecté ;
- `majLe` : horodatage serveur Firebase.

Ces champs techniques ne sont pas fusionnés comme des champs métier. Chaque transaction relit le document courant avant de décider de l'écriture.

## 5. Suppressions

Le prototype Web existant utilise déjà `deleted: true`. Le socle de migration conserve cette règle : une suppression est un marqueur, les documents ne sont pas physiquement effacés. Cela facilite la reprise, l'audit et la détection des suppressions concurrentes.

## 6. Sortie du navigateur

Une application Web ne peut pas imposer un texte libre dans la boîte native de fermeture des navigateurs. Le comportement prévu est donc :

- navigation interne, déconnexion ou bouton Quitter : dialogue CBPManagement avec **Enregistrer et quitter**, **Quitter sans enregistrer**, **Annuler** ;
- fermeture d'onglet ou de fenêtre : avertissement natif générique du navigateur ;
- au retour : proposer de reprendre le brouillon local enregistré dans IndexedDB.

Pour un formulaire encore ouvert et non ajouté/modifié, les écrans doivent renseigner `hasFormChanges()` et implémenter `stageForms()` afin de sauvegarder ses valeurs dans le brouillon local. Lors d'une fermeture native d'onglet, le navigateur ne permet pas d'exécuter un dialogue asynchrone fiable : les formulaires devront donc aussi persister leurs brouillons au fil de la saisie.

## 7. Limites et garanties

- La sauvegarde parcourt les documents un par un ; une sauvegarde peut donc réussir partiellement. Les succès sont conservés, les erreurs et conflits restent en attente.
- Une transaction Firestore ne fonctionne pas hors ligne. Dans ce cas, la copie locale reste disponible et l'erreur est signalée ; aucun succès distant ne doit être affiché.
- Les opérations métier composées qui exigent plusieurs documents atomiques (par exemple finaliser une facture et marquer plusieurs opérations de production) devront être regroupées en transaction multi-documents avant d'être activées. Le socle actuel ne prétend pas encore garantir cette atomicité pour tous les flux métier.
- Les règles de sécurité Firestore restent l'autorité réelle. Le contrôle `canWrite` côté interface n'est qu'une protection UX ; il ne remplace pas les Security Rules.
