# Authentification, rôles et sécurité

## 1. Deux mécanismes d'identité différents ont été trouvés

### Prototype Web fourni

- projet Firebase : `cbpm-8ac0e` ;
- connexion par Firebase Authentication ;
- profil métier dans `utilisateurs/{uid}` ;
- rattachement par `entrepriseId` ;
- rôle lu dans le champ `role` ;
- le code Web actuel autorise l'écriture si `role === "admin"` ; les autres profils sont en lecture seule ;
- l'application vérifie aussi `entreprises/{entrepriseId}.etat` et bloque l'accès si l'entreprise est suspendue.

C'est cette identité Web qui est conservée sans recréer les comptes ni demander un changement de mot de passe.

### Application Java fournie

- comptes locaux dans des fichiers `.properties` du dossier de données utilisateur ;
- empreintes de mots de passe dérivées avec `PBKDF2WithHmacSHA256` (210 000 itérations, sel de 16 octets, 256 bits) ;
- rôles Java `Administrateur` et `Consultation` ;
- miroir des comptes dans un autre projet Firebase, `cbpmanagement2026`, sous le chemin historique `/comptes/{idCompte}/sauvegardes/utilisateur_{identifiant}` ;
- la sauvegarde Java est distincte des profils du prototype Web.

Ces comptes ne sont pas des utilisateurs Firebase Authentication du projet Web. Le hash Java n'est pas un mot de passe réutilisable par le navigateur et ne doit pas être copié dans les documents Firestore. La migration de ces identités, si elle est nécessaire, devra être traitée comme une procédure séparée : correspondance vérifiée de la personne et de l'entreprise, invitation ou réinitialisation sécurisée des identifiants, attribution contrôlée du rôle. Aucun compte ne doit être deviné ou fusionné sur la seule base du nom d'utilisateur.

## 2. Projets Firebase

Le code Web cible utilise `cbpm-8ac0e`. Le code Java de sauvegarde quotidienne et de miroir de comptes utilise `cbpmanagement2026`. Les projets et leurs chemins Firestore sont différents.

La migration proposée conserve le projet Web comme cible. Les documents `CBPM-Daily-v1` du projet Java ne doivent pas être écrasés dans les collections métier : ils représentent des sauvegardes/synthèses groupées par jour.

## 3. Autorisations

- L'application conserve les profils Web existants et leur valeur `role`.
- Le rôle `admin` du Web garde les droits d'écriture actuellement prévus.
- Un compte sans droit d'écriture garde la lecture seule ; le dépôt bloque aussi les appels de modification côté client.
- Le contrôle Java `Administrateur` / `Consultation` n'est pas converti automatiquement en profil Firebase Web.
- Le contrôle côté navigateur n'est jamais la frontière de sécurité : les règles Firestore doivent valider `request.auth.uid`, l'appartenance à l'entreprise et le rôle réel.

## 4. Règles Firestore à obtenir et auditer

Les règles de sécurité Firestore réelles n'étaient pas présentes dans les deux fichiers fournis. Elles n'ont donc pas pu être vérifiées ici et aucune nouvelle règle ne doit être déployée à l'aveugle.

Avant la mise en production, vérifier au minimum :

1. un utilisateur ne peut lire que l'entreprise à laquelle son profil `utilisateurs/{uid}.entrepriseId` le rattache ;
2. un utilisateur ne peut pas modifier son propre `role` ou `entrepriseId` ;
3. seul un profil autorisé peut écrire dans les collections de son entreprise ;
4. le champ `deleted` et les champs techniques ne peuvent pas servir à contourner les règles ;
5. les utilisateurs d'une entreprise ne peuvent pas lire les données d'une autre entreprise ;
6. les opérations de gestion des comptes sont réservées aux administrateurs et vérifiées côté serveur/règles.

La configuration Firebase utilisée par une application cliente n'est pas une clé de service. Aucun compte de service, secret Admin SDK, mot de passe SMTP ou autre secret serveur ne doit être livré dans les fichiers JavaScript publics.

## 5. Messagerie

Les paramètres SMTP/IMAP Java sont locaux. Une application Web ne doit pas exposer les mots de passe mail dans le code du navigateur, IndexedDB partagé ou les documents Firestore. L'envoi et la consultation des messages devront passer par un service serveur authentifié, avec secrets gérés côté serveur et autorisations par entreprise.

## 6. Données locales

IndexedDB stocke uniquement les brouillons métier et leurs bases de comparaison. La clé de brouillon inclut l'identifiant de l'entreprise et le UID Firebase, afin qu'un autre compte connecté sur le même navigateur ne reprenne pas le brouillon du premier. Les mots de passe et secrets de connexion ne doivent jamais être placés dans le brouillon.
