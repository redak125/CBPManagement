# Schéma de données cible

## 1. Collections

Toutes les collections de gestion sont sous le chemin déjà utilisé par l'application Web :

`entreprises/{entrepriseId}/{collection}/{documentId}`

| Collection | Rôle | Source Java |
|---|---|---|
| `app_meta` | métadonnées de dossier / application | `app_meta` |
| `affect` | familles d'affectation des dépenses | `affect` |
| `sousaff` | sous-affectations de dépenses | `sousaff` |
| `client` | fiches clients | `client` |
| `fournisseur` | fiches fournisseurs | `fournisseur` |
| `appro` | achats et services approvisionnés | `appro` |
| `prod` | opérations de production et services | `prod` |
| `recette` | encaissements / recettes | `recette` |
| `depense` | dépenses et paiements | `depense` |
| `transfert` | transferts entre comptes de trésorerie | `transfert` |
| `personnel` | employés | `personnel` |
| `materiel` | véhicules et équipements | `materiel` |
| `prod_appro` | catalogue des produits d'approvisionnement | `prod_appro` |
| `silo` | silos | `silo` |
| `prod_fini` | produits finis et services vendus | `prod_fini` |
| `facture` | factures et liens vers opérations facturées | `facture` |
| `regstock` | régularisations de stock | `regstock` |
| `journal` | journal des opérations | `journal` |
| `parametres` | paramètres société du prototype Web | paramètres d'entreprise Web |

Les profils utilisateurs restent dans la collection racine `utilisateurs/{uid}`. Ils ne sont pas des documents métier sous `entreprises/{id}`.

## 2. Types utilisés par le Web existant

Le prototype Web distingue les types suivants :

- texte : chaînes JavaScript ;
- date : chaîne ISO `YYYY-MM-DD` ;
- numérique : nombre JavaScript ;
- case à cocher : booléen ;
- référence vers un autre document : ID Firestore sous forme de chaîne ;
- champs calculés : nombres dérivés, recalculés avant enregistrement.

Dans le Java, les valeurs du modèle `Rec` sont enregistrées sous forme de chaînes. L'import doit donc convertir les champs numériques et booléens identifiés, sans convertir les identifiants textuels comme les téléphones, immatriculations, RC, NIF, NIS ou RIB.

Le socle `migration-plan.js` convertit les champs numériques métier connus (`qte`, `pu`, `taux`, `ht`, `tvam`, `ttc`, `dosage`, `montant`, `remise`, `net`, `marge`, `theorique`, `reel`, `ecart`) ainsi que les valeurs booléennes explicites (`0/1`, `true/false`). Les valeurs comme `Oui` et `Non` ne sont pas interprétées arbitrairement.

## 3. Références connues à convertir

`reference-mapper.js` traite explicitement les relations Java suivantes :

| Table source | Champ | Collection cible | Clé de correspondance |
|---|---|---|---|
| `appro` | `fournisseur` | `fournisseur` | `nom` |
| `appro` | `produit` | `prod_appro` | `nature + nom` |
| `appro` | `silo` | `silo` | `nom` |
| `prod` | `client` | `client` | `nom` |
| `prod` | `produit` | `prod_fini` | nature produit/service + nom |
| `prod` | `silo` | `silo` | `nom` |
| `prod` | `camion` | `materiel` | `immat` |
| `prod` | `chauffeur` | `personnel` | `nom + prénom` |
| `recette` | `debiteur` | `client` | `nom` |
| `facture` | `client` | `client` | `nom` |
| `depense` | `aff` | `affect` | `nom` |
| `depense` | `sousaff` | fournisseur, client ou `sousaff` selon l'affectation | nom ou affectation + nom |
| `depense` | `benef` | `personnel` si charge de personnel | `nom + prénom` |

Les champs vides facultatifs sont ignorés. Une relation obligatoire sans correspondance, ou toute relation ambiguë, est bloquée et renvoyée dans `referenceReview`.

Les références des autres tables ou les particularités constatées dans les données réelles restent à valider avant import. Il ne faut pas extrapoler une relation sur la seule ressemblance de deux libellés.

## 4. Identifiants

Pour les nouvelles lignes importées, le plan crée un ID déterministe de la forme `legacy_{empreinte}`. Ce choix permet de retrouver la même ligne lors d'une nouvelle préparation du même fichier source. Les lignes déjà présentes sont rapprochées par clé métier lorsque celle-ci est sûre.

Le plan n'effectue aucune écriture Firestore. Il distingue :

- `create` : nouvelle ligne candidate ;
- `already-present` : ligne déjà présente et identique ;
- `review-existing` : correspondance trouvée mais contenu différent ;
- `ambiguous-match` : plusieurs documents distants correspondent ;
- `duplicate-in-source` : clé métier répétée dans le fichier source ;
- `review-references` : références liées à vérifier.

Une ligne `review-existing`, `ambiguous-match`, `duplicate-in-source` ou `review-references` ne doit pas être importée automatiquement.

## 5. Métadonnées

Les nouvelles écritures Web continuent d'utiliser :

- `version` : version de concurrence ;
- `majPar` : utilisateur ayant effectué la sauvegarde ;
- `majLe` : date d'écriture serveur ;
- `deleted` : suppression logique.

Les champs `version`, `majPar` et `majLe` sont exclus de la fusion métier. L'ID Firestore est porté par le document lui-même et n'est pas dupliqué dans la charge métier sauf besoin explicite.

## 6. Données séparées des tables métier

- `param` Java : préférences locales, retirées du `.cbpm` récent ; elles doivent être reconstituées/vérifiées dans l'écran de paramètres.
- `mailcfg` Java : configuration de messagerie stockée séparément du dossier ; elle doit être migrée vers une solution serveur sécurisée, pas vers Firestore en clair.
- `dettes_clients` et `dettes_fournisseurs` : tableaux calculés, non importés comme collections indépendantes.
- sauvegardes quotidiennes `CBPM-Daily-v1` du projet historique : agrégats et synthèses, pas le modèle transactionnel ligne par ligne.
